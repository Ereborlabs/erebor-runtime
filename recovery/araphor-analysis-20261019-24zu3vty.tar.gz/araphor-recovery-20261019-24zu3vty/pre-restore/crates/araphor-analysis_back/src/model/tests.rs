use std::collections::BTreeMap;
use std::sync::Arc;
use std::time::Duration;

use araphor_analysis_sdk as sdk;
use erebor_runtime_error::{ErrorExt, RetryHint, StatusCode};
use sdk::arrow_array::UInt64Array;

use super::*;
use crate::testing::QueryFixture;
use crate::{AnalysisReadControl, AnalysisSelectionV1, Limits, SqlReasonV1};

type TestResult = std::result::Result<(), Box<dyn std::error::Error + Send + Sync>>;

fn port(name: &str, column: &str) -> sdk::Port {
    sdk::Port::new(
        name,
        sdk::Schema::new(vec![sdk::Field::new(column, sdk::DataType::UInt64, false)]),
    )
}

fn batch(port: &sdk::Port, rows: Vec<u64>) -> sdk::Result<sdk::RecordBatch> {
    Ok(sdk::RecordBatch::try_new(
        Arc::new(port.schema.clone()),
        vec![Arc::new(UInt64Array::from(rows))],
    )?)
}

fn control() -> araphor_data::Result<AnalysisReadControl> {
    AnalysisReadControl::with_timeout(Duration::from_secs(30))
}

pub(in crate::model) fn evaluate(
    owner: &Arc<Engine>,
    tenant: [u8; 16],
    control: &AnalysisReadControl,
    package: &sdk::Package,
    admitted: &Arc<AdmittedExport>,
    evaluation: &sdk::Evaluation,
    inputs: Option<Arc<araphor_query::inputs::InputSet>>,
) -> crate::Result<SqlModelOutputV1> {
    let engine = Arc::clone(owner);
    let control = control.within(control.remaining()?)?;
    let package = package.clone();
    let admitted = Arc::clone(admitted);
    let evaluation = evaluation.clone();
    let memory = inputs.as_ref().map_or_else(
        || owner.memory().scope(),
        |inputs| Arc::clone(inputs.memory()),
    );
    owner.wait(async move {
        let result = ModelRun::evaluate(
            &engine,
            &memory,
            tenant,
            &control,
            &package,
            &admitted,
            &evaluation,
            inputs,
        )
        .await;
        drop(admitted);
        Ok(result)
    })?
}

#[test]
fn sql_model_state_provenance() -> TestResult {
    let fixture = QueryFixture::new()?;
    let owner = fixture.owner(Limits {
        evaluate_timeout: Some(Duration::from_secs(30)),
        ..Default::default()
    })?;
    let events = port("events", "id");
    let mut counts = port("counts", "count");
    counts.evidence_required = true;
    let mut model = sdk::Model::new("count", vec![events.clone()], vec![counts.clone()]);
    model.checkpoint = Some(sdk::CheckpointSpec {
        version: 1,
        datasets: vec![port("state", "count")],
    });
    model.reasons.push(sdk::Reason {
        code: "denials.repeated".into(),
        details: counts.schema.clone(),
    });
    model.reasons.push(sdk::Reason {
        code: "denials.empty".into(),
        details: sdk::Schema::empty(),
    });
    let package = sdk::Package::new("denials", "1", vec![model.clone()]);
    let evaluation = sdk::Evaluation {
        export: "count".into(),
        parameters: None,
        inputs: vec![sdk::Input {
            data: sdk::Dataset {
                name: "events".into(),
                batches: vec![batch(&events, vec![1, 2, 3])?],
            },
            revision: sdk::Revision {
                owner: "fixture".into(),
                id: "1".into(),
                window: None,
            },
            coverage: sdk::Coverage {
                state: sdk::CoverageState::Complete,
                limits: Vec::new(),
            },
        }],
        context: sdk::EvaluationContext {
            id: "run".into(),
            time_utc_ns: 100,
            seed: None,
            limits: model.limits,
        },
        checkpoint: Some(sdk::Checkpoint {
            version: 1,
            datasets: vec![sdk::Dataset {
                name: "state".into(),
                batches: vec![batch(&port("state", "count"), vec![9])?],
            }],
        }),
    };
    let program = SqlModelV1 {
        outputs: BTreeMap::from([("counts".into(), "SELECT CAST(COUNT(*) AS BIGINT UNSIGNED) AS count FROM events".into())]),
        checkpoint: BTreeMap::from([("state".into(), "SELECT count FROM prior_state".into())]),
        evidence: Some("SELECT 'counts' AS output_dataset, CAST(0 AS BIGINT UNSIGNED) AS output_row, 'events' AS input_dataset, __row_index AS input_row FROM events".into()),
        reasons: vec![SqlReasonV1 { output: "counts".into(), code: "denials.repeated".into(), sql: "SELECT __row_index AS output_row, count FROM output_counts".into() }, SqlReasonV1 { output: "counts".into(), code: "denials.empty".into(), sql: "SELECT __row_index AS output_row FROM output_counts".into() }],
    };
    let admitted = AdmittedExport::admit(&owner, &model, Some(&program)).map(Arc::new)?;
    let result = evaluate(
        &owner,
        [1; 16],
        &control()?,
        &package,
        &admitted,
        &evaluation,
        None,
    )?;
    assert_eq!(result.output.evidence.len(), 3);
    assert_eq!(result.output.reasons.len(), 2);
    assert_eq!(result.output.reasons[1].details.num_rows(), 1);
    assert_eq!(
        result.output.datasets[0].batches[0],
        batch(&counts, vec![3])?
    );
    assert_eq!(
        result
            .output
            .checkpoint
            .as_ref()
            .ok_or("checkpoint")?
            .datasets[0]
            .batches[0],
        batch(&port("state", "count"), vec![9])?
    );
    let mut bad = program.clone();
    bad.evidence = Some("SELECT 'counts' AS output_dataset, CAST(0 AS BIGINT UNSIGNED) AS output_row, 'events' AS input_dataset, CAST(99 AS BIGINT UNSIGNED) AS input_row".into());
    drop(result);
    let mut supplied = package.clone();
    supplied.exports[0].input_mode = sdk::InputMode::Resolved;
    supplied.exports[0].inputs[0].source =
        sdk::InputSource::Query("SELECT missing FROM absent".into());
    assert!(AdmittedExport::admit(&owner, &supplied.exports[0], Some(&program)).is_err());
    let supplied = evaluate(
        &owner,
        [1; 16],
        &control()?,
        &package,
        &admitted,
        &evaluation,
        None,
    )?;
    assert_eq!(
        supplied.output.datasets[0].batches[0],
        batch(&counts, vec![3])?
    );
    drop(supplied);
    let mut reused = program.clone();
    reused
        .checkpoint
        .insert("state".into(), "SELECT count FROM output_counts".into());
    let reused_admitted = AdmittedExport::admit(&owner, &model, Some(&reused)).map(Arc::new)?;
    let reused = evaluate(
        &owner,
        [1; 16],
        &control()?,
        &package,
        &reused_admitted,
        &evaluation,
        None,
    )?;
    assert_eq!(
        reused
            .output
            .checkpoint
            .as_ref()
            .ok_or("checkpoint reuse")?
            .datasets[0]
            .batches[0],
        batch(&port("state", "count"), vec![3])?
    );
    drop(reused);
    let bad_admitted = AdmittedExport::admit(&owner, &model, Some(&bad)).map(Arc::new)?;
    assert!(evaluate(
        &owner,
        [1; 16],
        &control()?,
        &package,
        &bad_admitted,
        &evaluation,
        None,
    )
    .is_err());
    for sql in [
        "SELECT * FROM read_csv('/etc/passwd')",
        "SELECT * FROM events; DROP TABLE events",
        "SELECT * FROM absent",
    ] {
        bad.outputs.insert("counts".into(), sql.into());
        assert!(AdmittedExport::admit(&owner, &model, Some(&bad)).is_err());
    }
    Ok(())
}

#[test]
fn sql_model_source_bounds() -> TestResult {
    let fixture = QueryFixture::new()?;
    for cursor in 1..=3 {
        fixture.event(cursor, cursor * 100, 7)?;
    }
    let owner = fixture.owner(Limits {
        output_rows: 1,
        extract_timeout: Some(Duration::from_secs(30)),
        evaluate_timeout: Some(Duration::from_secs(30)),
        ..Default::default()
    })?;
    let selection =
        AnalysisSelectionV1::new(fixture.source.tenant_id, vec![fixture.source.clone()]);
    let port = port("events", "id");
    let mut model = sdk::Model::new("source", Vec::new(), vec![port.clone()]);
    model.input_mode = sdk::InputMode::Resolved;
    model.inputs.push(sdk::InputPort {
        port: port.clone(),
        source: sdk::InputSource::Query(
            "SELECT source_cursor AS id FROM events ORDER BY source_cursor".into(),
        ),
    });
    let revision = fixture.store.meta()?.commit_revision;
    let admitted = AdmittedExport::admit(&owner, &model, None).map(Arc::new)?;
    let capacity = owner
        .limits()
        .input_capacity
        .ok_or("configured input capacity")?;
    let read = |selection: AnalysisSelectionV1,
                now|
     -> crate::Result<Arc<araphor_query::inputs::InputSet>> {
        let tenant = selection.tenant_id;
        let inputs = admitted.inputs.read(
            Arc::clone(&owner),
            selection,
            "scope".into(),
            &control()?,
            now,
        )?;
        drop(owner.reserve_evaluation(tenant)?);
        assert!(owner.memory().reserve_input(capacity).is_err());
        Ok(inputs)
    };
    let first = read(selection.clone(), 1_000)?;
    assert_eq!(
        first.inputs[0]
            .data
            .batches
            .iter()
            .map(|batch| batch.num_rows())
            .sum::<usize>(),
        3
    );
    assert_eq!(first.witnesses().count(), 3);
    for relation in [
        "events",
        "source_receipts",
        "coverage",
        "expired_ranges",
        "recovery_gaps",
    ] {
        assert!(first
            .source_revisions()
            .contains(&(relation.into(), revision)));
    }
    assert!(!first
        .source_revisions()
        .iter()
        .any(|(name, _)| name == "analysis_results"));
    let second = read(selection.clone(), 2_000)?;
    assert_eq!(first.inputs[0].revision, second.inputs[0].revision);
    let result = SqlDatasetOutputV1::query(
        &owner,
        fixture.source.tenant_id,
        &control()?,
        std::slice::from_ref(&first.inputs[0].data),
        "SELECT * FROM events WHERE id > 1 ORDER BY id",
        sdk::Limits::default(),
    )?;
    assert_eq!(result.data.batches[0].num_columns(), 2);
    assert_eq!(result.data.batches[0].num_rows(), 2);
    assert_eq!(
        result.data.batches[0].schema().field(1).name(),
        "__row_index"
    );
    assert_eq!(
        result.data.batches[0]
            .column(1)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or("query row index")?
            .values()
            .as_ref(),
        &[1, 2],
    );
    drop(result);
    let denied = SqlDatasetOutputV1::query(
        &owner,
        fixture.source.tenant_id,
        &control()?,
        std::slice::from_ref(&first.inputs[0].data),
        "WITH unused AS (SELECT * FROM datafusion.public.catalog) SELECT id FROM events",
        sdk::Limits::default(),
    );
    assert!(denied.is_err());
    let error = denied
        .err()
        .ok_or("undeclared dataset source was accepted")?;
    assert_eq!(error.status_code(), StatusCode::InvalidArguments);
    assert_eq!(error.retry_hint(), RetryHint::NonRetryable);
    assert_eq!(error.package_code(), crate::PackageErrorCodeV1::Invalid);
    drop(owner.reserve_evaluation(fixture.source.tenant_id)?);
    let mut corrected = selection;
    corrected.received_until = std::ops::Bound::Included(200);
    let third = read(corrected, 2_000)?;
    assert_ne!(first.inputs[0].revision, third.inputs[0].revision);
    assert_eq!(third.inputs[0].data.batches[0].num_rows(), 2);
    assert_ne!(third.inputs[0].coverage.state, sdk::CoverageState::Complete);
    let alias = first.inputs[0].data.batches[0].column(0).slice(0, 1);
    drop((first, second, third));
    assert!(owner
        .memory()
        .reserve_input(
            owner
                .limits()
                .input_capacity
                .ok_or("configured input capacity")?
        )
        .is_err());
    assert_eq!(
        alias
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or("model input index")?
            .value(0),
        1
    );
    drop(owner.reserve_evaluation(fixture.source.tenant_id)?);
    drop(alias);
    drop(
        owner.memory().reserve_input(
            owner
                .limits()
                .input_capacity
                .ok_or("configured input capacity")?,
        )?,
    );
    Ok(())
}

#[test]
fn sql_model_exact_parameters() -> TestResult {
    let schema = sdk::Schema::new(vec![
        sdk::Field::new("unsigned", sdk::DataType::UInt64, false),
        sdk::Field::new("signed", sdk::DataType::Int64, false),
    ]);
    let valid = serde_json::json!({"unsigned": u64::MAX, "signed": i64::MIN});
    let batch = araphor_data::decode_parameters(&schema, Some(&valid))?.ok_or("parameters")?;
    assert_eq!(
        batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or("uint")?
            .value(0),
        u64::MAX
    );
    for invalid in [
        serde_json::json!({"unsigned":1.5,"signed":0}),
        serde_json::json!({"unsigned":-1,"signed":0}),
        serde_json::json!({"unsigned":1,"signed":0,"unknown":1}),
        serde_json::json!({"unsigned":1}),
    ] {
        assert!(araphor_data::decode_parameters(&schema, Some(&invalid)).is_err());
    }
    Ok(())
}

#[test]
fn admitted_program_order() -> TestResult {
    let fixture = QueryFixture::new()?;
    let owner = fixture.owner(Limits {
        evaluate_timeout: Some(Duration::from_secs(30)),
        ..Default::default()
    })?;
    let mut model = sdk::Model::new(
        "ordered",
        Vec::new(),
        vec![port("ZRows", "count"), port("ARows", "count")],
    );
    model.checkpoint = Some(sdk::CheckpointSpec {
        version: 1,
        datasets: vec![port("ZState", "count"), port("AState", "count")],
    });
    model.reasons = ["ordered.z", "ordered.a"]
        .map(|code| sdk::Reason {
            code: code.into(),
            details: port("details", "count").schema,
        })
        .into();
    let mut program = SqlModelV1 {
        outputs: BTreeMap::from([
            ("ARows".into(), "SELECT 9::BIGINT UNSIGNED AS count".into()),
            ("ZRows".into(), "SELECT 7::BIGINT UNSIGNED AS count".into()),
        ]),
        checkpoint: BTreeMap::from([
            ("AState".into(), "SELECT count FROM \"output_ARows\"".into()),
            ("ZState".into(), "SELECT count FROM \"output_ZRows\"".into()),
        ]),
        reasons: vec![
            SqlReasonV1 {
                output: "ARows".into(),
                code: "ordered.a".into(),
                sql: "SELECT __row_index AS output_row, count FROM \"output_ARows\"".into(),
            },
            SqlReasonV1 {
                output: "ZRows".into(),
                code: "ordered.z".into(),
                sql: "SELECT __row_index AS output_row, count FROM \"output_ZRows\"".into(),
            },
        ],
        ..Default::default()
    };
    for (output, code) in [("missing", "ordered.a"), ("ARows", "missing")] {
        let mut invalid = program.clone();
        invalid.reasons[0].output = output.into();
        invalid.reasons[0].code = code.into();
        assert!(AdmittedExport::admit(&owner, &model, Some(&invalid)).is_err());
    }
    let mut admitted = AdmittedExport::admit(&owner, &model, Some(&program)).map(Arc::new)?;
    let before = admitted.allocated_bytes();
    let growth = {
        let plan = Arc::get_mut(&mut admitted)
            .ok_or("shared admitted model")?
            .model
            .as_mut()
            .ok_or("admitted model")?;
        assert_eq!((plan.reasons[0].0, plan.reasons[0].1), (1, 1));
        assert_eq!((plan.reasons[1].0, plan.reasons[1].1), (0, 0));
        let mut growth = 0;
        for statements in [&mut plan.outputs, &mut plan.checkpoint] {
            let capacity = statements.capacity();
            statements.reserve_exact(8);
            growth += (statements.capacity() - capacity) * std::mem::size_of::<Arc<LogicalPlan>>();
        }
        let capacity = plan.reasons.capacity();
        plan.reasons.reserve_exact(8);
        growth += (plan.reasons.capacity() - capacity)
            * std::mem::size_of::<(usize, usize, Arc<LogicalPlan>)>();
        growth
    };
    assert_eq!(admitted.allocated_bytes(), before + growth);
    program.outputs.clear();
    program.checkpoint.clear();
    program.reasons.clear();
    let package = sdk::Package::new("ordered", "1", vec![model.clone()]);
    let evaluation = sdk::Evaluation {
        export: model.name.clone(),
        inputs: Vec::new(),
        parameters: None,
        context: sdk::EvaluationContext {
            id: "ordered".into(),
            time_utc_ns: 100,
            seed: None,
            limits: model.limits,
        },
        checkpoint: None,
    };
    let output = evaluate(
        &owner,
        [1; 16],
        &control()?,
        &package,
        &admitted,
        &evaluation,
        None,
    )?;
    for (index, expected) in [7, 9].into_iter().enumerate() {
        let data = &output.output.datasets[index];
        assert_eq!(data.name, model.outputs[index].name);
        assert_eq!(
            data.batches,
            vec![batch(&model.outputs[index], vec![expected])?]
        );
    }
    let checkpoint = output.output.checkpoint.as_ref().ok_or("checkpoint")?;
    for (index, expected) in [7, 9].into_iter().enumerate() {
        let port = &model.checkpoint.as_ref().ok_or("checkpoint spec")?.datasets[index];
        assert_eq!(checkpoint.datasets[index].name, port.name);
        assert_eq!(
            checkpoint.datasets[index].batches,
            vec![batch(port, vec![expected])?]
        );
    }
    assert_eq!(output.output.reasons.len(), 2);
    for (reason, (dataset, code, value)) in output
        .output
        .reasons
        .iter()
        .zip([("ARows", "ordered.a", 9), ("ZRows", "ordered.z", 7)])
    {
        assert_eq!(
            reason.output,
            sdk::RowRef {
                dataset: dataset.into(),
                row: 0
            }
        );
        assert_eq!(reason.code, code);
        assert_eq!(
            reason.details,
            batch(&port("details", "count"), vec![value])?
        );
    }
    drop(output);
    for (output, reason) in [(usize::MAX, 1), (1, usize::MAX)] {
        let plan = Arc::get_mut(&mut admitted)
            .ok_or("shared admitted model")?
            .model
            .as_mut()
            .ok_or("admitted model")?;
        (plan.reasons[0].0, plan.reasons[0].1) = (output, reason);
        assert!(matches!(
            evaluate(
                &owner,
                [1; 16],
                &control()?,
                &package,
                &admitted,
                &evaluation,
                None,
            ),
            Err(crate::Error::ModelInvalid {
                field: "model reason declaration",
                ..
            })
        ));
        drop(
            owner.memory().reserve_input(
                owner
                    .limits()
                    .input_capacity
                    .ok_or("configured input capacity")?,
            )?,
        );
    }
    let plan = Arc::get_mut(&mut admitted)
        .ok_or("shared admitted model")?
        .model
        .as_mut()
        .ok_or("admitted model")?;
    (plan.reasons[0].0, plan.reasons[0].1) = (1, 1);
    plan.outputs.pop();
    assert!(matches!(
        evaluate(
            &owner,
            [1; 16],
            &control()?,
            &package,
            &admitted,
            &evaluation,
            None,
        ),
        Err(crate::Error::ModelInvalid {
            field: "model admitted output",
            ..
        })
    ));
    drop(
        owner.memory().reserve_input(
            owner
                .limits()
                .input_capacity
                .ok_or("configured input capacity")?,
        )?,
    );
    Ok(())
}

mod clock;
mod stream;
mod types;

#[tokio::test(flavor = "current_thread")]
async fn program_in_current_thread() -> TestResult {
    admitted_program_order()
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn program_in_multithread() -> TestResult {
    admitted_program_order()
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn program_in_blocking_worker() -> TestResult {
    tokio::task::spawn_blocking(admitted_program_order).await?
}
