use std::sync::Arc;

use crate::analysis::{PackageActivationV1, PackageKeyV1, PackageResultV1};
use crate::{AnalysisReadControl, Result};
use araphor_analysis_sdk as sdk;
use snafu::ResultExt as _;

use super::installed::snapshot::InstalledBundle;
use super::owner::InstalledContext;
use super::{
    AnalysisPackageOwner, PackageActionV1 as Action, PackageErrorCodeV1 as Code,
    PackageExportStatusV1, PackageGrantV1, PackageResponseV1,
};

pub(super) struct PackageQuery<'a> {
    pub scope: &'a str,
    pub package: &'a str,
    pub export: &'a str,
    pub id: Option<&'a str>,
    pub sql: &'a str,
}

impl AnalysisPackageOwner {
    pub(super) fn activations(
        &self,
        tenant: [u8; 16],
        scope: &str,
        package: &str,
    ) -> Result<Vec<PackageActivationV1>> {
        let selected = self
            .store
            .package_activations(tenant, scope, Some(package))?;
        if selected.len() > 64 {
            return Err(Code::Limit.error("package exports").into());
        }
        Ok(selected)
    }

    pub(super) fn inspect(
        &self,
        grant: &PackageGrantV1,
        scope: &str,
        package: &str,
        admitted: Option<&Arc<InstalledBundle>>,
        control: &AnalysisReadControl,
    ) -> Result<PackageResponseV1> {
        self.check(grant, Action::Inspect)?;
        self.refresh_package(grant, scope, package, admitted, control)?;
        let mut exports = Vec::new();
        for active in self.activations(grant.selection.tenant_id, scope, package)? {
            let context: InstalledContext = Self::decode(&active.metadata)?;
            Self::permits(grant, &context.grant)?;
            let loaded;
            let artifact = match admitted
                .filter(|bundle| bundle.value.root == context.root)
                .and_then(|bundle| {
                    bundle.value.artifacts.iter().find(|artifact| {
                        artifact.descriptor.id == package
                            && artifact.descriptor.revision == active.revision
                    })
                }) {
                Some(artifact) => artifact,
                None => {
                    let stored = self
                        .store
                        .package_revision(active.key.tenant_id, package, &active.revision)?
                        .ok_or_else(|| Code::Missing.error("installed artifact"))?;
                    loaded = stored.decode_artifact()?;
                    &loaded
                }
            };
            let model = artifact
                .descriptor
                .exports
                .iter()
                .find(|model| model.name == active.key.export)
                .ok_or_else(|| Code::Missing.error("installed export"))?;
            let mut results = Vec::new();
            for result in self.store.package_results(&active.key)? {
                let installed: InstalledContext = Self::decode(&result.commit.activation.metadata)?;
                match Self::permits(grant, &installed.grant) {
                    Err(araphor_data::Error::Package {
                        code: Code::Denied, ..
                    }) => continue,
                    permitted => permitted?,
                }
                results.push(Self::receipt(&result)?);
            }
            let readiness = if !active.active
                && matches!(context.readiness, super::PackageReadinessV1::Ready)
            {
                super::PackageReadinessV1::Inactive
            } else if active.checkpoint_revision > context.status_checkpoint {
                super::PackageReadinessV1::Ready
            } else {
                context.readiness
            };
            exports.push(PackageExportStatusV1::new(
                artifact, model, &active, readiness, results,
            ));
        }
        self.check(grant, Action::Inspect)?;
        Ok(PackageResponseV1 {
            definition: None,
            image: None,
            scope_id: scope.into(),
            package_id: package.into(),
            exports,
            tests: Vec::new(),
            output: None,
        })
    }

    pub fn read_output(
        &self,
        grant: &PackageGrantV1,
        scope: &str,
        package: &str,
        export: &str,
        id: &str,
    ) -> Result<sdk::wire::Output> {
        self.check(grant, Action::Inspect)?;
        let key = PackageKeyV1 {
            tenant_id: grant.selection.tenant_id,
            scope_id: scope.into(),
            package_id: package.into(),
            export: export.into(),
        };
        self.store
            .package_activation(&key)?
            .ok_or_else(|| Code::Missing.error("package scope"))?;
        let result = self
            .store
            .package_result(key.tenant_id, id)?
            .filter(|result| result.commit.activation.key == key)
            .ok_or_else(|| Code::Missing.error("package result"))?;
        let output = Self::result_output(grant, &result)?;
        self.check(grant, Action::Inspect)?;
        Ok(output)
    }

    fn result_output(
        grant: &PackageGrantV1,
        result: &PackageResultV1,
    ) -> Result<sdk::wire::Output> {
        let installed: InstalledContext = Self::decode(&result.commit.activation.metadata)?;
        Self::permits(grant, &installed.grant)?;
        let result = &result.commit;
        let mut output: sdk::wire::Output = Self::decode(&result.datasets)?;
        output.checkpoint = if result.checkpoint.is_empty() {
            None
        } else {
            Some(Self::decode(&result.checkpoint)?)
        };
        Ok(output)
    }

    pub(super) fn query_output(
        &self,
        grant: &PackageGrantV1,
        request: PackageQuery<'_>,
        control: &AnalysisReadControl,
    ) -> Result<PackageResponseV1> {
        let PackageQuery {
            scope,
            package,
            export,
            id,
            sql,
        } = request;
        self.check(grant, Action::Inspect)?;
        let key = PackageKeyV1 {
            tenant_id: grant.selection.tenant_id,
            scope_id: scope.into(),
            package_id: package.into(),
            export: export.into(),
        };
        let active = self
            .store
            .package_activation(&key)?
            .ok_or_else(|| Code::Missing.error("package scope"))?;
        let id = id
            .or(active.result_id.as_deref())
            .ok_or_else(|| Code::Missing.error("package result"))?;
        if active.result_id.as_deref() == Some(id) {
            self.refresh_package(grant, scope, package, None, control)?;
        }
        let stored = self
            .store
            .package_result(key.tenant_id, id)?
            .filter(|result| result.commit.activation.key == key)
            .ok_or_else(|| Code::Missing.error("package result"))?;
        let revision = self
            .store
            .package_revision(key.tenant_id, package, &stored.commit.activation.revision)?
            .ok_or_else(|| Code::Missing.error("result artifact"))?;
        let artifact = revision.decode_artifact()?;
        let model = artifact
            .descriptor
            .exports
            .iter()
            .find(|model| model.name == export)
            .ok_or_else(|| Code::Missing.error("result export"))?;
        let output = Self::decode_output(&Self::result_output(grant, &stored)?, model)?;
        self.check(grant, Action::Inspect)?;
        control.check()?;
        let query = crate::SqlDatasetOutputV1::query(
            &self.query,
            key.tenant_id,
            control,
            &output.datasets,
            sql,
            model.limits,
        )?;
        let schema = query
            .data
            .batches
            .first()
            .ok_or_else(|| Code::Invalid.error("query output schema"))?
            .schema();
        let dataset = sdk::wire::Dataset::encode(&query.data, &schema, model.limits)
            .context(crate::AnalysisContractSnafu)?;
        let mut response = PackageResponseV1 {
            definition: None,
            image: None,
            scope_id: scope.into(),
            package_id: package.into(),
            exports: Vec::new(),
            tests: Vec::new(),
            output: None,
        };
        let current = active.active && active.revision == stored.commit.activation.revision;
        let readiness = if current {
            super::PackageReadinessV1::Ready
        } else {
            super::PackageReadinessV1::Inactive
        };
        let mut status = PackageExportStatusV1::new(
            &artifact,
            model,
            &stored.commit.activation,
            readiness,
            vec![Self::receipt(&stored)?],
        );
        status.active = current;
        if status.activation_revision == 0 {
            status.activation_revision = stored.commit_revision;
        }
        response.exports = vec![status];
        response.output = Some(sdk::wire::Output {
            datasets: vec![dataset],
            ..Default::default()
        });
        self.check(grant, Action::Inspect)?;
        Ok(response)
    }

    pub(crate) fn permits(
        grant: &PackageGrantV1,
        installed: &PackageGrantV1,
    ) -> araphor_data::Result<()> {
        Self::permits_selection(grant, &installed.selection)
    }

    pub(super) fn permits_selection(
        grant: &PackageGrantV1,
        selection: &crate::AnalysisSelectionV1,
    ) -> araphor_data::Result<()> {
        if grant.selection != *selection
            && grant.selection != crate::AnalysisSelectionV1::tenant(selection.tenant_id)
        {
            return Err(Code::Denied.error("whole package scope"));
        }
        Ok(())
    }
}
