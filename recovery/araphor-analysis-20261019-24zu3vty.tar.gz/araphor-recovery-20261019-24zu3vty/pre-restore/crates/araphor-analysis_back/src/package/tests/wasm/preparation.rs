use super::*;
use crate::AnalysisReadControl;
use sha2::Digest as _;
use std::{sync::Arc, time::Duration};

#[test]
fn preparation_precedes_evaluation_deadline() -> TestResult {
    let fixture = crate::package::tests::Fixture::new()?;
    let query = crate::Engine::new(
        Arc::clone(&fixture.store),
        crate::Limits {
            input_capacity: Some(128 * 1024 * 1024),
            output_capacity: Some(16 * 1024 * 1024),
            evaluate_timeout: Some(Duration::from_nanos(1)),
            ..Default::default()
        },
    )?;
    let owner = crate::AnalysisPackageOwner::new(Arc::clone(&query), fixture.authority.clone())?;
    let package = super::component("1").artifacts.remove(0).descriptor;
    let input = sdk::Evaluation {
        export: "evaluate".into(),
        inputs: Vec::new(),
        checkpoint: None,
        parameters: araphor_data::decode_parameters(
            &package.exports[0].parameters,
            Some(&serde_json::json!({"mode": "echo", "amount": 42})),
        )?,
        context: sdk::EvaluationContext {
            id: "runtime-test".into(),
            time_utc_ns: 123,
            seed: Some(7),
            limits: package.exports[0].limits,
        },
    };
    let artifact = crate::package::PackageArtifactV1 {
        descriptor: package,
        implementations: vec![crate::package::PackageImplementationV1::Wasm {
            exports: vec!["evaluate".into()],
            artifact: araphor_analysis_builtins::components::RUNTIME.to_vec(),
        }],
        fixtures: Vec::new(),
    };
    let bundle = crate::package::installed::snapshot::InstalledBundle::new(
        &query,
        crate::package::PackageBundleV1 {
            schema_version: 1,
            root: crate::package::PackageRefV1 {
                package_id: artifact.descriptor.id.clone(),
                revision: artifact.descriptor.revision.clone(),
            },
            artifacts: vec![artifact],
        },
        query.memory(),
    )?;
    let artifact = &bundle.value.artifacts[0];
    let index = bundle.export_index(
        &artifact.descriptor.id,
        &artifact.descriptor.revision,
        &input.export,
    )?;
    let control = AnalysisReadControl::with_timeout(Duration::from_secs(30))?;
    let digest = sha2::Sha256::digest(araphor_analysis_builtins::components::RUNTIME).into();
    assert!(owner.wasm.cached(&digest)?.is_none());
    assert!(matches!(
        owner.evaluate_artifact(
            [1; 16],
            bundle,
            index,
            input,
            None,
            &query.memory().scope(),
            &control
        ),
        Err(crate::Error::Data {
            source: araphor_data::Error::AnalysisReadDeadline { .. }
        })
    ));
    assert!(owner.wasm.cached(&digest)?.is_some());
    control.check()?;
    query.reserve_evaluation([1; 16])?;
    query.memory().reserve_input(
        query
            .limits()
            .input_capacity
            .ok_or("configured input capacity")?,
    )?;
    query.memory().reserve_output(
        query
            .limits()
            .output_capacity
            .ok_or("configured output capacity")?,
    )?;
    Ok(())
}
