pub(crate) use araphor_package_runtime::wasm::WasmExecution;

#[cfg(any(test, feature = "test-fixtures"))]
impl super::AnalysisPackageOwner {
    pub fn prepare_test_code(&mut self) -> crate::Result<()> {
        self.wasm = WasmExecution::fixture_code(self.limits.wasm)?;
        Ok(())
    }

    #[cfg(test)]
    pub fn observe_guest(&self) -> crate::Result<std::sync::mpsc::Receiver<()>> {
        self.wasm.observe_guest().map_err(crate::Error::from)
    }
}
