use std::sync::Arc;
use std::time::Duration;

use araphor_analysis_sdk as sdk;
use araphor_query::execution::{Engine, Limits};
use araphor_query::inputs::GraphInputs;
use sdk::arrow_array::{Array, BinaryArray, StringArray, UInt64Array};

use crate::graph::tests::native_storage::CommitFixture;
use crate::package::{
    InstalledAnalysis, PackageArtifactV1, PackageBundleV1, PackageGrantV1, PackageImplementationV1,
    PackageRequestV1,
};
use crate::{
    AnalysisContextRefV1, AnalysisContextVersionV1, AnalysisReadControl, AnalysisSelectionV1,
    ContextSensitivityV1, GraphEdgeTypeV1, GraphSubjectKeyV1, GraphSubjectKindV1, GraphTraversalV1,
};

type TestResult<T = ()> = std::result::Result<T, Box<dyn std::error::Error>>;

fn control() -> araphor_data::Result<AnalysisReadControl> {
    AnalysisReadControl::with_timeout(Duration::from_secs(30))
}

fn column<'a, T: Array + 'static>(batch: &'a sdk::RecordBatch, name: &str) -> TestResult<&'a T> {
    batch
        .column_by_name(name)
        .and_then(|value| value.as_any().downcast_ref())
        .ok_or_else(|| format!("column {name} is absent or has a different type").into())
}

fn bundle(inputs: &[sdk::Input]) -> TestResult<PackageBundleV1> {
    let ports = inputs
        .iter()
        .map(|input| {
            let batch = input.data.batches.first().ok_or("input batch absent")?;
            Ok(sdk::Port::new(
                &input.data.name,
                batch.schema().as_ref().clone(),
            ))
        })
        .collect::<TestResult<Vec<_>>>()?;
    let mut outputs = ports.clone();
    outputs.push(sdk::Port::new(
        "metadata",
        sdk::Schema::new(vec![
            sdk::Field::new("dataset", sdk::DataType::Utf8, false),
            sdk::Field::new("revision", sdk::DataType::Utf8, false),
            sdk::Field::new("coverage", sdk::DataType::Utf8, false),
        ]),
    ));
    let descriptor = sdk::Package::new(
        "runtime-fixture",
        "1",
        vec![sdk::Model::new("echo-inputs", ports, outputs)],
    );
    let artifact = PackageArtifactV1 {
        descriptor,
        implementations: vec![PackageImplementationV1::Wasm {
            exports: vec!["echo-inputs".into()],
            artifact: araphor_analysis_builtins::components::RUNTIME.to_vec(),
        }],
        fixtures: Vec::new(),
    };
    Ok(PackageBundleV1 {
        schema_version: 1,
        root: artifact.reference(),
        artifacts: vec![artifact],
    })
}

fn assert_inputs(
    execution: &InstalledAnalysis,
    tenant: [u8; 16],
    inputs: &GraphInputs,
    id: &str,
) -> TestResult {
    let evaluation = sdk::Evaluation {
        export: "echo-inputs".into(),
        inputs: inputs.inputs().to_vec(),
        parameters: None,
        checkpoint: None,
        context: sdk::EvaluationContext {
            id: id.into(),
            time_utc_ns: 10,
            seed: None,
            limits: sdk::Limits::default(),
        },
    };
    let evaluated = execution.evaluate(tenant, "runtime-fixture", &evaluation, &control()?)?;
    evaluated
        .descriptor
        .validate_output(&evaluated.evaluation, &evaluated.output)?;
    assert_eq!(evaluated.revision, "1");
    assert_eq!(evaluated.target, "wasm");
    assert_eq!(evaluated.output.datasets.len(), inputs.inputs().len() + 1);
    let metadata = evaluated
        .output
        .datasets
        .iter()
        .find(|dataset| dataset.name == "metadata")
        .ok_or("metadata dataset absent")?;
    let rows = metadata.batches.first().ok_or("metadata batch absent")?;
    assert_eq!(rows.num_rows(), inputs.inputs().len());
    for (index, input) in inputs.inputs().iter().enumerate() {
        let output = evaluated
            .output
            .datasets
            .iter()
            .find(|dataset| dataset.name == input.data.name)
            .ok_or("returned dataset absent")?;
        assert_eq!(output.batches, input.data.batches);
        assert_eq!(
            column::<StringArray>(rows, "dataset")?.value(index),
            input.data.name
        );
        assert_eq!(
            serde_json::from_str::<sdk::Revision>(
                column::<StringArray>(rows, "revision")?.value(index)
            )?,
            input.revision
        );
        assert_eq!(
            serde_json::from_str::<sdk::Coverage>(
                column::<StringArray>(rows, "coverage")?.value(index)
            )?,
            input.coverage
        );
    }
    Ok(())
}

#[tokio::test]
async fn native_graph_component_inputs() -> TestResult {
    let mut fixture = CommitFixture::new()?;
    let source = fixture.snapshot.scope.identity.clone();
    let tenant = source.tenant_id;
    let subjects = (0_u64..3)
        .map(|index| {
            GraphSubjectKeyV1::native(
                &source,
                GraphSubjectKindV1::Task,
                index.to_be_bytes().to_vec(),
            )
        })
        .collect::<Vec<_>>();
    fixture.snapshot.graph.subjects = subjects.clone();
    let edge = fixture.snapshot.graph.edges[0].clone();
    fixture.snapshot.graph.edges = subjects
        .windows(2)
        .map(|pair| {
            let mut edge = edge.clone();
            edge.key.from = pair[0].clone();
            edge.key.to = pair[1].clone();
            edge.key.edge_type = GraphEdgeTypeV1::NativeParent;
            edge
        })
        .collect();
    let context = AnalysisContextVersionV1 {
        key: crate::AnalysisContextKeyV1 {
            tenant_id: tenant,
            owner_id: "sdk-native-fixture".into(),
            entity_key: b"entity".to_vec(),
            lifetime_key: b"lifetime".to_vec(),
            owner_revision: 1,
        },
        valid_from_utc_ns: None,
        valid_until_utc_ns: None,
        sensitivity: ContextSensitivityV1::HostRestricted,
        body: b"retained context".to_vec(),
    };
    let revision = fixture.store.commit_context(&context)?;
    fixture
        .snapshot
        .input_manifest
        .context
        .push(context.key.clone());
    fixture.snapshot.graph.revision = fixture.snapshot.input_manifest.clone();
    for finding in &mut fixture.snapshot.findings {
        finding.revision = fixture.snapshot.input_manifest.clone();
    }
    fixture.request.context_revision = revision;
    fixture.request.context_refs.push(AnalysisContextRefV1 {
        key: context.key,
        commit_revision: revision,
    });
    fixture.request.body = serde_json::to_vec(&fixture.snapshot)?;
    fixture.store.commit_graph(&fixture.request, true)?;
    let selection = AnalysisSelectionV1::new(tenant, vec![source.clone()]);
    let request = GraphTraversalV1 {
        seeds: vec![subjects[0].clone()],
        ..Default::default()
    };
    let execution = InstalledAnalysis::testing(Some(fixture.store.clone()), tenant)?;
    let owner = Engine::new(fixture.store.clone(), Limits::default())?;
    let inputs = owner.graph_inputs(&selection, &request, &control()?)?;
    execution
        .testing_owner()
        .execute(
            PackageGrantV1 {
                principal: "fixture".into(),
                revision: 1,
                selection: AnalysisSelectionV1::tenant(tenant),
                expires_utc_ns: None,
                authorization_id: None,
            },
            PackageRequestV1::Install {
                scope_id: crate::AnalysisPackageOwner::DOMAIN_SCOPE.into(),
                bundle: bundle(inputs.inputs())?,
                parameters: None,
            },
            Arc::new(AnalysisReadControl::with_timeout(Duration::from_secs(60))?),
        )
        .await?;
    let execution = execution.snapshot(tenant)?;
    assert_inputs(&execution, tenant, &inputs, "native")?;
    assert_eq!(inputs.inputs()[0].data.batches[0].num_rows(), 2);
    assert_eq!(inputs.inputs()[1].data.batches[0].num_rows(), 1);
    assert!(inputs.traversal.hop_boundary);
    assert_eq!(
        inputs.inputs()[0].coverage.state,
        sdk::CoverageState::Unknown
    );
    assert!(matches!(
        owner.graph_inputs(&selection, &request, &control()?),
        Err(araphor_query::Error::Busy {
            resource: "evaluation",
            ..
        })
    ));
    let revision = inputs.inputs()[0].revision.clone();
    drop(inputs);
    let mut snapshot = fixture.snapshot.clone();
    snapshot.previous_result_id = Some(fixture.request.result_id.clone());
    snapshot.graph.subjects.clear();
    snapshot.graph.edges.clear();
    snapshot.graph.branches.clear();
    snapshot.findings.clear();
    let mut replacement = fixture.request.clone();
    replacement.expected_cursor = 1;
    replacement.result_id = "graph:sdk-empty".into();
    replacement.created_utc_ns += 1;
    replacement.body = serde_json::to_vec(&snapshot)?;
    fixture.store.commit_graph(&replacement, false)?;
    let inputs = owner.graph_inputs(&selection, &request, &control()?)?;
    assert_inputs(&execution, tenant, &inputs, "empty")?;
    assert_eq!(inputs.traversal.result_ids, vec![replacement.result_id]);
    assert_ne!(inputs.inputs()[0].revision, revision);
    assert_eq!(inputs.inputs()[0].data.batches[0].num_rows(), 0);
    assert_eq!(inputs.inputs()[1].data.batches[0].num_rows(), 0);
    let manifest = &inputs.inputs()[2].data.batches[0];
    assert_eq!(manifest.num_rows(), 1);
    assert_eq!(
        column::<UInt64Array>(manifest, "subject_count")?.value(0),
        0
    );
    assert_eq!(
        column::<UInt64Array>(manifest, "relationship_count")?.value(0),
        0
    );
    assert_eq!(
        column::<StringArray>(manifest, "previous_result_id")?.value(0),
        fixture.request.result_id
    );
    assert_eq!(
        column::<BinaryArray>(manifest, "source_key")?.value(0),
        source.key()
    );
    Ok(())
}
