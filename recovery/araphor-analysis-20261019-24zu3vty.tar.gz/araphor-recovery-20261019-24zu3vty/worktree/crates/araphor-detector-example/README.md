# Compiled Detector Example

`BurstDetector` counts selected observations for each exact lifetime and task.
At the configured `threshold`, it returns one contextual finding with all
selected record ordinals as evidence. Different lifetimes remain separate.
The `example-burst.THRESHOLD` reason has UInt64 `threshold` and `count` details.
The next `graph.state.v1` checkpoint records the selected row count.

The caller supplies the normalized `records`, `facts`, and `manifest` inputs.
The SDK checks the returned datasets, evidence, reasons, and checkpoint.
The result has `confirmed: false` and the `CONTEXTUAL_ACTIVITY` limit.
A match does not establish malicious intent or grant response authority.

## Build the folder

Install the Rust `wasm32-unknown-unknown` target on the author machine. Build
from the repository root with the pinned lock file and a fixed compile-time
seed:

```sh
rtk proxy env CARGO_TARGET_DIR=/tmp/araphor-wasm-build CARGO_INCREMENTAL=0 CONST_RANDOM_SEED=araphor-analysis-v1 cargo build --locked --release --target wasm32-unknown-unknown -p araphor-detector-example
rtk proxy env CARGO_TARGET_DIR=/tmp/araphor-wasm-build cargo run --locked -p araphor-detector-example --example build_package -- /tmp/araphor-wasm-build/wasm32-unknown-unknown/release/araphor_detector_example.wasm /tmp/araphor-burst-package
rtk proxy cargo test -p araphor-detector-example --lib
```

The folder has the SDK declarations and an OCI layout: `oci-layout`,
`index.json`, and content-addressed files under `blobs/sha256/`. The OCI config
contains package metadata. A typed raw layer contains the validated component
bytes. The folder builder depends on the SDK and the Rust component encoder.
It does not require an Araphor host build.

Use the same source, lock file, target, and Rust compiler to reproduce the
artifact. The recorded reproducibility proof uses Rust 1.97.1. The fixed
`CONST_RANDOM_SEED` controls the compile-time hash seed in Arrow dependencies.
Recorded evaluation time and seed remain separate contract values.

Host Cargo builds generate repository component bytes from source through the
[built-in artifact owner](../araphor-analysis-builtins/README.md#generated-components).
Cargo stores these components in `OUT_DIR`. Do not commit generated Wasm files.
The author commands above produce the separate folder for installation.

## Install the built folder

Compute the OCI manifest digest and pin its exact `sha256:` value in Control `package_trust`
configuration. Use the package mutation grant for the selected tenant. Read
the [package operations guide](../../docs/plans/mithril-hugging-face-intrusion-prevention/phase-7-mithril-control-and-detection-packages/phase-7-5-graphs-findings-and-notifications/package-operations.md)
for the grant and trust format.

```sh
rtk proxy araphor image digest /tmp/araphor-burst-package
rtk proxy araphor --profile ./operator.json image install /tmp/araphor-burst-package
rtk proxy araphor --profile ./operator.json image inspect example-burst --revision 1
```

Installation retains the exact image. It starts no Discovery and supplies no
input bindings or parameters. Set `threshold` in a definition call. The
[definition guide](../../docs/guides/araphor-discovery-definition-review.md)
shows the SQL, PRQL, and YAML forms. Installation runs no hook and does not
rebuild Araphor.

The former graph owner supplied inputs and retained durable receipts and
checkpoints. That owner has been removed. Its restart and retry results are
historical proof. Reactive graph execution and running instances remain
**Not done** in the [current plan](../../docs/plans/araphor-package-jobs.md).
