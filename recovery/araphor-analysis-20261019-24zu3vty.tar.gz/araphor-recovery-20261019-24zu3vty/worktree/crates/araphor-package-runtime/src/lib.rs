use std::sync::{Arc, Mutex};

use araphor_analysis_sdk as sdk;
use araphor_package::{PackageBundleV1, PackageImplementationV1, PackageRefV1};
use snafu::ResultExt as _;

pub use araphor_data::{AnalysisReadControl, PackageErrorCodeV1};
pub use tokio_util::task::TaskTracker;

mod error;
mod limits;
pub mod native;
pub mod wasm;

pub(crate) use error::{
    AnalysisBusySnafu, AnalysisContractSnafu, IoSnafu, PackageNativeSnafu, PackageWasmSnafu,
};
pub use error::{Error, Result};
pub use limits::{Limits, WasmLimits};

pub struct Runtime {
    limits: Limits,
    wasm: Mutex<Option<Arc<wasm::WasmExecution>>>,
}

struct Pending {
    control: AnalysisReadControl,
    complete: bool,
}

impl Drop for Pending {
    fn drop(&mut self) {
        if !self.complete {
            let _cancelled = self.control.cancel();
        }
    }
}

impl Runtime {
    pub fn new(limits: Limits) -> Result<Arc<Self>> {
        limits.native.validate()?;
        Ok(Arc::new(Self {
            limits,
            wasm: Mutex::new(None),
        }))
    }

    fn wasm(&self) -> Result<Arc<wasm::WasmExecution>> {
        let mut runtime = self
            .wasm
            .lock()
            .map_err(|_| PackageErrorCodeV1::Incomplete.error("Wasm runtime lock"))?;
        if runtime.is_none() {
            *runtime = Some(Arc::new(wasm::WasmExecution::new(self.limits.wasm)?));
        }
        runtime
            .as_ref()
            .cloned()
            .ok_or_else(|| PackageErrorCodeV1::Incomplete.error("Wasm runtime").into())
    }

    pub async fn evaluate(
        self: &Arc<Self>,
        bundle: Arc<PackageBundleV1>,
        package: PackageRefV1,
        mut evaluation: sdk::Evaluation,
        control: AnalysisReadControl,
        workers: &TaskTracker,
    ) -> Result<(sdk::Evaluation, sdk::Output)> {
        let worker_token = workers.token();
        if workers.is_closed() {
            return Err(PackageErrorCodeV1::Incomplete
                .error("runtime scope is closed")
                .into());
        }
        control.check()?;
        let artifact = bundle.artifact(&package)?;
        let wasm = match artifact.implementation(&evaluation.export)? {
            PackageImplementationV1::Wasm { .. } => Some(self.wasm()?),
            PackageImplementationV1::Native { .. } => None,
            _ => {
                return Err(PackageErrorCodeV1::Unsupported
                    .error("runtime target")
                    .into())
            }
        };
        let stage = control.within(None)?;
        let mut pending = Pending {
            control: stage.within(None)?,
            complete: false,
        };
        let mut worker = tokio::task::spawn_blocking(move || {
            let _worker_token = worker_token;
            let artifact = bundle.artifact(&package)?;
            let implementation = artifact.implementation(&evaluation.export)?;
            if let Some(runtime) = wasm {
                evaluation.context.limits =
                    wasm::WasmExecution::limits(evaluation.context.limits, &runtime.limits);
                let PackageImplementationV1::Wasm {
                    artifact: bytes, ..
                } = implementation
                else {
                    return Err(PackageErrorCodeV1::Invalid.error("runtime target").into());
                };
                let output = runtime.evaluate(&artifact.descriptor, &evaluation, bytes, &stage)?;
                Ok((evaluation, output))
            } else {
                let PackageImplementationV1::Native {
                    artifact: bytes,
                    qualification: Some(qualification),
                    ..
                } = implementation
                else {
                    return Err(PackageErrorCodeV1::Unsupported
                        .error("native qualification")
                        .into());
                };
                let checked = artifact
                    .descriptor
                    .check_evaluation(&evaluation)
                    .context(AnalysisContractSnafu)?;
                let library = native::NativeLibrary::load(bytes, qualification, &stage)?;
                let output = library.call(&checked, evaluation.context.limits, &stage)?;
                checked
                    .validate_output(&output)
                    .context(AnalysisContractSnafu)?;
                stage.check()?;
                Ok((evaluation, output))
            }
        });
        let result = tokio::select! {
            result = &mut worker => result.context(error::WorkerSnafu)?,
            () = control.cancelled() => {
                let _cancelled = pending.control.cancel();
                let _finished = worker.await;
                control.check()?;
                return Err(PackageErrorCodeV1::Incomplete.error("runtime cancellation").into());
            }
            () = control.expired() => {
                let expired = control.check();
                let _cancelled = pending.control.cancel();
                let _finished = worker.await;
                expired?;
                return Err(PackageErrorCodeV1::Incomplete.error("runtime deadline").into());
            }
        };
        pending.complete = true;
        control.check()?;
        result
    }
}
