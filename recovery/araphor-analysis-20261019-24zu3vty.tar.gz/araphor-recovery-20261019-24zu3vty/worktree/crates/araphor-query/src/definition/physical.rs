use std::any::Any;
use std::collections::BTreeMap;
use std::fmt;
use std::sync::{Arc, Mutex};

use araphor_analysis_sdk as sdk;
use araphor_data::AnalysisReadControl;
use araphor_package_runtime::{Runtime, TaskTracker};
use datafusion::arrow::compute::concat_batches;
use datafusion::common::tree_node::TreeNodeRecursion;
use datafusion::common::{DataFusionError, Result};
use datafusion::execution::memory_pool::MemoryReservation;
use datafusion::execution::TaskContext;
use datafusion::logical_expr::LogicalPlan;
use datafusion::physical_expr::EquivalenceProperties;
use datafusion::physical_plan::execution_plan::{Boundedness, EmissionType};
use datafusion::physical_plan::stream::RecordBatchStreamAdapter;
use datafusion::physical_plan::{
    execute_stream, DisplayAs, DisplayFormatType, Distribution, ExecutionPlan, Partitioning,
    PlanProperties, SendableRecordBatchStream,
};
use futures_util::future::{BoxFuture, FutureExt, Shared, WeakShared};
use futures_util::{stream, TryStreamExt};

use super::PackageCall;
use crate::memory::Memory;
use crate::sources::SourceSnapshot;

mod sql;

#[derive(Clone, Debug)]
pub struct Invocation {
    pub id: String,
    pub seed: Option<u64>,
    pub checkpoints: BTreeMap<u64, sdk::Checkpoint>,
    pub limits: sdk::Limits,
}

impl Default for Invocation {
    fn default() -> Self {
        Self {
            id: "package-call".into(),
            seed: None,
            checkpoints: BTreeMap::new(),
            limits: sdk::Limits {
                max_batches: u32::MAX,
                max_rows: u64::MAX,
                max_bytes: u64::MAX,
                max_checkpoint_bytes: u64::MAX,
            },
        }
    }
}

pub struct CallResult {
    pub evaluation: sdk::Evaluation,
    pub output: sdk::Output,
    _input: MemoryReservation,
    _output: MemoryReservation,
}

impl fmt::Debug for CallResult {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CallResult")
            .field("export", &self.evaluation.export)
            .field("outputs", &self.output.datasets.len())
            .finish_non_exhaustive()
    }
}

type Outcome = std::result::Result<Arc<CallResult>, Arc<DataFusionError>>;
type CallFuture = BoxFuture<'static, Outcome>;
type SharedCall = Shared<CallFuture>;

enum CallState {
    Running(WeakShared<CallFuture>),
    Complete(Outcome),
}

pub struct CallContext {
    runtime: Arc<Runtime>,
    invocation: Invocation,
    memory: Arc<Memory>,
    control: Arc<AnalysisReadControl>,
    now: u64,
    workers: TaskTracker,
    calls: Mutex<BTreeMap<u64, CallState>>,
}

impl fmt::Debug for CallContext {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CallContext")
            .field("id", &self.invocation.id)
            .field("now", &self.now)
            .finish_non_exhaustive()
    }
}

impl CallContext {
    pub fn new(
        runtime: Arc<Runtime>,
        invocation: Invocation,
        memory: Arc<Memory>,
        control: Arc<AnalysisReadControl>,
        now: u64,
    ) -> Arc<Self> {
        Arc::new(Self {
            runtime,
            invocation,
            memory,
            control,
            now,
            workers: TaskTracker::new(),
            calls: Mutex::default(),
        })
    }

    pub fn results(&self) -> Result<BTreeMap<u64, Arc<CallResult>>> {
        self.calls
            .lock()
            .map_err(|_| internal("package result lock is poisoned"))?
            .iter()
            .map(|(id, call)| {
                let CallState::Complete(result) = call else {
                    return Err(internal("package call has not completed"));
                };
                result
                    .clone()
                    .map(|result| (*id, result))
                    .map_err(DataFusionError::Shared)
            })
            .collect()
    }

    pub async fn finish(&self) {
        {
            let _calls = self
                .calls
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            self.workers.close();
        }
        self.workers.wait().await;
    }

    fn call(self: &Arc<Self>, plan: PackageExec, context: Arc<TaskContext>) -> Result<SharedCall> {
        let mut calls = self
            .calls
            .lock()
            .map_err(|_| internal("package result lock is poisoned"))?;
        let id = plan.call.id;
        if self.workers.is_closed() {
            return Err(internal("package execution is closed"));
        }
        if let Some(call) = calls.get(&id) {
            return match call {
                CallState::Running(call) => call
                    .upgrade()
                    .ok_or_else(|| internal("package call was abandoned")),
                CallState::Complete(result) => {
                    let result = result.clone();
                    Ok(async move { result }.boxed().shared())
                }
            };
        }
        let token = self.workers.token();
        let owner = Arc::clone(self);
        let future = async move {
            let _token = token;
            let result = plan
                .evaluate(Arc::clone(&owner), context)
                .await
                .map(Arc::new)
                .map_err(Arc::new);
            if let Ok(mut calls) = owner.calls.lock() {
                calls.insert(id, CallState::Complete(result.clone()));
            }
            result
        }
        .boxed()
        .shared();
        calls.insert(
            id,
            CallState::Running(
                future
                    .downgrade()
                    .ok_or_else(|| internal("package call future is absent"))?,
            ),
        );
        Ok(future)
    }
}

#[derive(Clone)]
pub(crate) struct PackageExec {
    call: PackageCall,
    children: Vec<Arc<dyn ExecutionPlan>>,
    properties: Arc<PlanProperties>,
}

impl fmt::Debug for PackageExec {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PackageExec")
            .field("id", &self.call.id)
            .field("export", &self.call.export)
            .finish_non_exhaustive()
    }
}

impl PackageExec {
    pub(crate) fn new(
        call: &PackageCall,
        children: &[Arc<dyn ExecutionPlan>],
        logical: &[&LogicalPlan],
    ) -> Result<Self> {
        if children.len() != call.children.len() || logical.len() != children.len() {
            return Err(internal("package physical inputs changed"));
        }
        let properties = Arc::new(PlanProperties::new(
            EquivalenceProperties::new(Arc::clone(call.schema.inner())),
            Partitioning::UnknownPartitioning(1),
            EmissionType::Final,
            Boundedness::Bounded,
        ));
        Ok(Self {
            call: call.clone(),
            children: children.to_vec(),
            properties,
        })
    }

    async fn evaluate(
        &self,
        owner: Arc<CallContext>,
        context: Arc<TaskContext>,
    ) -> Result<CallResult> {
        owner.control.check().map_err(external)?;
        let source = context
            .session_config()
            .get_extension::<SourceSnapshot>()
            .ok_or_else(|| internal("package source snapshot is absent"))?;
        let snapshot = source.snapshot()?;
        if snapshot.selection.tenant_id != self.call.tenant {
            return Err(external(
                araphor_data::PackageErrorCodeV1::Denied.error("package call tenant"),
            ));
        }
        let model = self
            .call
            .descriptor
            .exports
            .iter()
            .find(|model| model.name == self.call.export)
            .ok_or_else(|| internal("package export is absent"))?;
        let requested = owner.invocation.limits;
        let limits = sdk::Limits {
            max_batches: requested.max_batches.min(model.limits.max_batches),
            max_rows: requested.max_rows.min(model.limits.max_rows),
            max_bytes: requested.max_bytes.min(model.limits.max_bytes),
            max_checkpoint_bytes: requested
                .max_checkpoint_bytes
                .min(model.limits.max_checkpoint_bytes),
        };
        let input = owner.memory.reserve_input(0)?;
        let mut budget = Budget::new(limits);
        let mut inputs = Vec::with_capacity(model.inputs.len());
        for (slot, port) in model.inputs.iter().enumerate() {
            let data = sdk::Dataset {
                name: port.port.name.clone(),
                batches: self
                    .collect(
                        slot,
                        &port.port.schema,
                        &owner,
                        &context,
                        &input,
                        true,
                        &mut budget,
                    )
                    .await?,
            };
            let mut inherited = Vec::new();
            self.call.children[slot].apply_with_subqueries(|plan| {
                if let LogicalPlan::Extension(extension) = plan {
                    if let Some(call) = extension.node.as_any().downcast_ref::<PackageCall>() {
                        if let Some(result) = owner.completed(call.id)? {
                            inherited.extend(result.evaluation.inputs.iter().cloned());
                        }
                        return Ok(TreeNodeRecursion::Jump);
                    }
                }
                Ok(TreeNodeRecursion::Continue)
            })?;
            inputs.push(
                self.call
                    .input_scope
                    .input_for(data, &snapshot, slot, &self.children[slot], &inherited)
                    .map_err(external)?,
            );
        }
        let parameters = if model.parameters.fields().is_empty() {
            None
        } else {
            let batches = self
                .collect(
                    model.inputs.len(),
                    &model.parameters,
                    &owner,
                    &context,
                    &input,
                    true,
                    &mut budget,
                )
                .await?;
            Some(concat_batches(
                &Arc::new(model.parameters.clone()),
                &batches,
            )?)
        };
        let mut evaluation = sdk::Evaluation {
            export: self.call.export.clone(),
            inputs,
            parameters,
            context: sdk::EvaluationContext {
                id: owner.invocation.id.clone(),
                time_utc_ns: i64::try_from(owner.now)
                    .map_err(|_| internal("package evaluation time is out of range"))?,
                seed: owner.invocation.seed,
                limits,
            },
            checkpoint: owner.invocation.checkpoints.get(&self.call.id).cloned(),
        };
        for batch in evaluation
            .checkpoint
            .iter()
            .flat_map(|checkpoint| &checkpoint.datasets)
            .flat_map(|data| &data.batches)
        {
            owner.memory.retain_input(batch, &input)?;
        }
        input.try_resize(input_metadata(&evaluation))?;
        let output_memory = owner.memory.reserve_output(0)?;
        let output = if self.call.sql.is_some() {
            let checked = self
                .call
                .descriptor
                .check_evaluation(&evaluation)
                .map_err(external)?;
            let output = self
                .sql(&evaluation, &owner, &context, &source, &output_memory)
                .await?;
            checked.validate_output(&output).map_err(external)?;
            output
        } else {
            let (effective, output) = owner
                .runtime
                .evaluate(
                    Arc::clone(&self.call.bundle),
                    self.call.package.clone(),
                    evaluation,
                    owner.control.within(None).map_err(external)?,
                    &owner.workers,
                )
                .await
                .map_err(external)?;
            evaluation = effective;
            output
        };
        owner.control.check().map_err(external)?;
        for batch in output
            .datasets
            .iter()
            .chain(
                output
                    .checkpoint
                    .iter()
                    .flat_map(|checkpoint| &checkpoint.datasets),
            )
            .flat_map(|data| &data.batches)
            .chain(output.reasons.iter().map(|reason| &reason.details))
        {
            owner.memory.retain_output(batch, &output_memory)?;
        }
        output_memory.try_resize(output_metadata(&output))?;
        Ok(CallResult {
            evaluation,
            output,
            _input: input,
            _output: output_memory,
        })
    }

    #[allow(clippy::too_many_arguments)]
    async fn collect(
        &self,
        slot: usize,
        schema: &sdk::Schema,
        owner: &CallContext,
        context: &Arc<TaskContext>,
        memory: &MemoryReservation,
        input: bool,
        budget: &mut Budget,
    ) -> Result<Vec<sdk::RecordBatch>> {
        let plan = self
            .children
            .get(slot)
            .ok_or_else(|| internal("package physical child is absent"))?;
        let mut stream = execute_stream(Arc::clone(plan), Arc::clone(context))?;
        let schema = Arc::new(schema.clone());
        let mut batches = Vec::new();
        while let Some(batch) = owner
            .control
            .query_async(async {
                stream
                    .try_next()
                    .await
                    .map_err(|source| crate::Error::Sql { source })
            })
            .await
            .map_err(external)?
        {
            let conversion = sdk::Dataset::conversion_bytes(&batch, &schema).map_err(external)?;
            let metadata = memory
                .size()
                .checked_add(std::mem::size_of::<sdk::RecordBatch>())
                .and_then(|bytes| {
                    batch
                        .num_columns()
                        .checked_mul(std::mem::size_of::<sdk::arrow_array::ArrayRef>())
                        .and_then(|headers| bytes.checked_add(headers))
                })
                .ok_or_else(limit)?;
            memory.try_resize(metadata.checked_add(conversion).ok_or_else(limit)?)?;
            let batch =
                sdk::Dataset::normalize_batch(batch, Arc::clone(&schema)).map_err(external)?;
            budget.add(&batch)?;
            if input {
                owner.memory.retain_input(&batch, memory)?;
            } else {
                owner.memory.retain_output(&batch, memory)?;
            }
            memory.try_resize(metadata)?;
            batches.push(batch);
        }
        if batches.is_empty() {
            let batch = sdk::RecordBatch::new_empty(schema);
            budget.add(&batch)?;
            batches.push(batch);
        }
        Ok(batches)
    }
}

impl CallContext {
    fn completed(&self, id: u64) -> Result<Option<Arc<CallResult>>> {
        match self
            .calls
            .lock()
            .map_err(|_| internal("package result lock is poisoned"))?
            .get(&id)
        {
            Some(CallState::Complete(result)) => {
                result.clone().map(Some).map_err(DataFusionError::Shared)
            }
            _ => Ok(None),
        }
    }
}

struct Budget {
    limits: sdk::Limits,
    rows: u64,
    bytes: u64,
    batches: u32,
    references: bool,
}

impl Budget {
    fn new(limits: sdk::Limits) -> Self {
        Self {
            limits,
            rows: 0,
            bytes: 0,
            batches: 0,
            references: false,
        }
    }
    fn references(limits: sdk::Limits) -> Self {
        Self {
            references: true,
            ..Self::new(limits)
        }
    }
    fn add(&mut self, batch: &sdk::RecordBatch) -> Result<()> {
        self.rows = self
            .rows
            .checked_add(batch.num_rows() as u64)
            .ok_or_else(limit)?;
        self.bytes = self
            .bytes
            .checked_add(batch.get_array_memory_size() as u64)
            .ok_or_else(limit)?;
        self.batches = self.batches.checked_add(1).ok_or_else(limit)?;
        if self.bytes > self.limits.max_bytes
            || (!self.references
                && (self.rows > self.limits.max_rows || self.batches > self.limits.max_batches))
        {
            return Err(limit());
        }
        Ok(())
    }
}

fn input_metadata(evaluation: &sdk::Evaluation) -> usize {
    evaluation.allocated_bytes().saturating_sub(
        evaluation
            .inputs
            .iter()
            .flat_map(|input| &input.data.batches)
            .chain(evaluation.parameters.iter())
            .chain(
                evaluation
                    .checkpoint
                    .iter()
                    .flat_map(|checkpoint| &checkpoint.datasets)
                    .flat_map(|data| &data.batches),
            )
            .flat_map(sdk::RecordBatch::columns)
            .map(|array| array.get_buffer_memory_size())
            .sum::<usize>(),
    )
}

fn output_metadata(output: &sdk::Output) -> usize {
    output.allocated_bytes().saturating_sub(
        output
            .datasets
            .iter()
            .chain(
                output
                    .checkpoint
                    .iter()
                    .flat_map(|checkpoint| &checkpoint.datasets),
            )
            .flat_map(|data| &data.batches)
            .chain(output.reasons.iter().map(|reason| &reason.details))
            .flat_map(sdk::RecordBatch::columns)
            .map(|array| array.get_buffer_memory_size())
            .sum::<usize>(),
    )
}

fn external(error: impl std::error::Error + Send + Sync + 'static) -> DataFusionError {
    DataFusionError::External(Box::new(error))
}
fn internal(message: &str) -> DataFusionError {
    DataFusionError::Internal(message.into())
}
fn limit() -> DataFusionError {
    DataFusionError::ResourcesExhausted("package relation exceeds evaluation limits".into())
}

impl DisplayAs for PackageExec {
    fn fmt_as(&self, _: DisplayFormatType, formatter: &mut fmt::Formatter) -> fmt::Result {
        write!(
            formatter,
            "PackageExec: id={} {}/{}",
            self.call.id, self.call.export, self.call.output
        )
    }
}

impl ExecutionPlan for PackageExec {
    fn name(&self) -> &str {
        "PackageExec"
    }
    fn as_any(&self) -> &dyn Any {
        self
    }
    fn properties(&self) -> &Arc<PlanProperties> {
        &self.properties
    }
    fn children(&self) -> Vec<&Arc<dyn ExecutionPlan>> {
        self.children.iter().collect()
    }
    fn required_input_distribution(&self) -> Vec<Distribution> {
        vec![Distribution::SinglePartition; self.children.len()]
    }
    fn with_new_children(
        self: Arc<Self>,
        children: Vec<Arc<dyn ExecutionPlan>>,
    ) -> Result<Arc<dyn ExecutionPlan>> {
        if children.len() != self.children.len() {
            return Err(internal("package physical child count changed"));
        }
        Ok(Arc::new(Self {
            children,
            ..self.as_ref().clone()
        }))
    }
    fn execute(
        &self,
        partition: usize,
        context: Arc<TaskContext>,
    ) -> Result<SendableRecordBatchStream> {
        if partition != 0 {
            return Err(internal("PackageExec has one output partition"));
        }
        let owner = context
            .session_config()
            .get_extension::<CallContext>()
            .ok_or_else(|| internal("package execution context is absent"))?;
        let plan = self.clone();
        let name = self.call.output.clone();
        let schema = self.schema();
        let batches = stream::once(async move {
            let result = owner
                .call(plan, context)?
                .await
                .map_err(DataFusionError::Shared)?;
            let output = result
                .output
                .datasets
                .iter()
                .find(|data| data.name == name)
                .ok_or_else(|| internal("package named output is absent"))?;
            Ok::<_, DataFusionError>(stream::iter(output.batches.clone().into_iter().map(
                move |batch| {
                    let _result = &result;
                    Ok(batch)
                },
            )))
        })
        .try_flatten();
        Ok(Box::pin(RecordBatchStreamAdapter::new(schema, batches)))
    }
}
