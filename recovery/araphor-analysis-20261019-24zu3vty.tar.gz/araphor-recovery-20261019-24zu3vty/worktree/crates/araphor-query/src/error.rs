use erebor_runtime_error::{ErrorExt, RetryHint, StatusCode};
use snafu::{Location, Snafu};

#[derive(Debug, Snafu)]
#[snafu(visibility(pub(crate)))]
pub enum Error {
    #[snafu(transparent)]
    Data { source: araphor_data::Error },
    #[snafu(transparent)]
    Contract { source: araphor_analysis_sdk::Error },
    #[snafu(display("SQL operation failed"))]
    Sql {
        source: datafusion::error::DataFusionError,
    },
    #[snafu(display("Invalid {field}"))]
    Invalid {
        field: &'static str,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("No {resource} capacity is available"))]
    Capacity {
        resource: &'static str,
        source: datafusion::error::DataFusionError,
    },
    #[snafu(display("No {resource} capacity is available"))]
    Busy {
        resource: &'static str,
        #[snafu(implicit)]
        location: Location,
    },
}

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Failure {
    InvalidQuery,
    InvalidCheckpoint,
    Unsupported,
    InputTooLarge,
    ResultTooLarge,
    CursorExpired,
    Cancelled,
    DeadlineExceeded,
    Busy,
    Denied,
    StorageUnavailable,
    OutputTimeout,
    EvaluationFailed,
}

impl Failure {
    fn package(code: araphor_data::PackageErrorCodeV1) -> Self {
        use araphor_data::PackageErrorCodeV1;
        match code {
            PackageErrorCodeV1::Invalid => Self::InvalidQuery,
            PackageErrorCodeV1::Limit => Self::InputTooLarge,
            PackageErrorCodeV1::Denied => Self::Denied,
            PackageErrorCodeV1::Unsupported => Self::Unsupported,
            PackageErrorCodeV1::Missing | PackageErrorCodeV1::Incomplete => {
                Self::StorageUnavailable
            }
            PackageErrorCodeV1::Conflict => Self::EvaluationFailed,
        }
    }

    fn contract(error: &araphor_analysis_sdk::Error) -> Self {
        use araphor_analysis_sdk::ErrorCode;
        match error.code() {
            ErrorCode::Invalid => Self::InvalidQuery,
            ErrorCode::Incompatible => Self::Unsupported,
            ErrorCode::Unauthorized => Self::Denied,
            ErrorCode::Incomplete => Self::StorageUnavailable,
            ErrorCode::Limit => Self::InputTooLarge,
            ErrorCode::Failed => Self::EvaluationFailed,
        }
    }

    fn data(error: &araphor_data::Error) -> Self {
        use araphor_data::Error;
        match error {
            Error::Definition { source } => match source {
                araphor_discovery_definition::Error::Io { .. } => Self::StorageUnavailable,
                _ => Self::InvalidQuery,
            },
            Error::AnalysisContract { source, .. } => Self::contract(source),
            Error::Package { code, .. } => Self::package(*code),
            Error::AnalysisInputTooLarge { .. } => Self::InputTooLarge,
            Error::AnalysisReadDenied { .. } => Self::Denied,
            Error::AnalysisUnavailable { .. } => Self::Unsupported,
            Error::AnalysisReplayExpired { .. } | Error::RetainedRangeExpired { .. } => {
                Self::CursorExpired
            }
            Error::AnalysisReadCancelled { .. } => Self::Cancelled,
            Error::AnalysisReadDeadline { .. } => Self::DeadlineExceeded,
            Error::AnalysisBusy { .. } => Self::Busy,
            Error::RetentionUnavailable { .. }
            | Error::StorageCapacity { .. }
            | Error::ProtectedInputCapacity { .. } => Self::StorageUnavailable,
            _ => Self::EvaluationFailed,
        }
    }

    fn runtime(error: &araphor_package_runtime::Error) -> Self {
        use araphor_package_runtime::Error;
        match error {
            Error::Data { source } => Self::data(source),
            Error::AnalysisContract { source, .. } => Self::contract(source),
            Error::AnalysisBusy { .. } => Self::Busy,
            Error::PackageNative { code, .. } | Error::PackageWasm { code, .. } => {
                Self::package(*code)
            }
            Error::Io { .. } => Self::StorageUnavailable,
            Error::Worker { .. } => Self::EvaluationFailed,
        }
    }

    pub fn native(error: &datafusion::error::DataFusionError) -> Self {
        let mut current: Option<&(dyn std::error::Error + 'static)> = Some(error);
        while let Some(source) = current {
            if let Some(source) = source.downcast_ref::<Error>() {
                return Self::from(source);
            }
            if let Some(source) = source.downcast_ref::<araphor_data::Error>() {
                return Self::data(source);
            }
            if let Some(source) = source.downcast_ref::<araphor_package_runtime::Error>() {
                return Self::runtime(source);
            }
            if let Some(source) = source.downcast_ref::<araphor_analysis_sdk::Error>() {
                return Self::contract(source);
            }
            current = source.source();
        }
        use datafusion::error::DataFusionError;
        match error.find_root() {
            DataFusionError::ResourcesExhausted(resource) if resource.contains("input") => {
                Self::InputTooLarge
            }
            DataFusionError::ResourcesExhausted(_) => Self::ResultTooLarge,
            DataFusionError::NotImplemented(_) => Self::Unsupported,
            DataFusionError::Plan(_)
            | DataFusionError::SQL(..)
            | DataFusionError::SchemaError(..) => Self::InvalidQuery,
            _ => Self::EvaluationFailed,
        }
    }
}

impl From<&Error> for Failure {
    fn from(error: &Error) -> Self {
        match error {
            Error::Data { source } => Self::data(source),
            Error::Contract { source } => Self::contract(source),
            Error::Sql { source } => Self::native(source),
            Error::Invalid { field, .. } if field.starts_with("cursor") => Self::InvalidCheckpoint,
            Error::Invalid { .. } => Self::InvalidQuery,
            Error::Busy { .. } | Error::Capacity { .. } => Self::Busy,
        }
    }
}

impl Error {
    fn domain<'a>(mut source: &'a (dyn std::error::Error + 'static)) -> Option<&'a dyn ErrorExt> {
        loop {
            if let Some(error) = source.downcast_ref::<Self>() {
                return Some(error);
            }
            if let Some(error) = source.downcast_ref::<araphor_data::Error>() {
                return Some(error);
            }
            if let Some(error) = source.downcast_ref::<araphor_package_runtime::Error>() {
                return Some(error);
            }
            if let Some(error) = source.downcast_ref::<araphor_analysis_sdk::Error>() {
                return Some(error);
            }
            source = source.source()?;
        }
    }
}

impl ErrorExt for Error {
    fn status_code(&self) -> StatusCode {
        use datafusion::error::DataFusionError;
        match self {
            Self::Data { source } => source.status_code(),
            Self::Contract { source } => source.status_code(),
            Self::Invalid { .. } => StatusCode::InvalidArguments,
            Self::Busy { .. } | Self::Capacity { .. } => StatusCode::Unavailable,
            Self::Sql { source } => match Self::domain(source) {
                Some(error) => error.status_code(),
                None => match source.find_root() {
                    DataFusionError::ResourcesExhausted(_)
                    | DataFusionError::Plan(_)
                    | DataFusionError::SchemaError(..)
                    | DataFusionError::SQL(..) => StatusCode::InvalidArguments,
                    DataFusionError::NotImplemented(_) => StatusCode::Unsupported,
                    _ => StatusCode::External,
                },
            },
        }
    }

    fn retry_hint(&self) -> RetryHint {
        match self {
            Self::Data { source } => source.retry_hint(),
            Self::Contract { source } => source.retry_hint(),
            Self::Busy { .. } | Self::Capacity { .. } => RetryHint::Retryable,
            Self::Sql { source } => {
                Self::domain(source).map_or(RetryHint::NonRetryable, ErrorExt::retry_hint)
            }
            _ => RetryHint::NonRetryable,
        }
    }

    fn as_any(&self) -> &dyn std::any::Any {
        self
    }

    fn output_msg(&self) -> String {
        match self {
            Self::Data { source } => source.output_msg(),
            Self::Contract { source } => source.output_msg(),
            _ => self.to_string(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use datafusion::error::DataFusionError;

    #[test]
    fn capacity_pressure_can_retry() {
        let memory = crate::memory::Memory::new(Some(8), Some(8));
        let held = memory.reserve_input(8).unwrap();
        let pressure = Error::Sql {
            source: memory.reserve_input(1).unwrap_err(),
        };
        assert_eq!(pressure.status_code(), StatusCode::Unavailable);
        assert_eq!(pressure.retry_hint(), RetryHint::Retryable);
        assert_eq!(Failure::from(&pressure), Failure::Busy);
        let oversize = Error::Sql {
            source: memory.reserve_input(9).unwrap_err(),
        };
        assert_eq!(oversize.status_code(), StatusCode::InvalidArguments);
        assert_eq!(oversize.retry_hint(), RetryHint::NonRetryable);
        assert_eq!(Failure::from(&oversize), Failure::InputTooLarge);
        drop(held);
        assert!(memory.reserve_input(8).is_ok());
    }

    #[test]
    fn wrapped_cancel_keeps_category() {
        let control = araphor_data::AnalysisReadControl::default();
        control.cancel().unwrap();
        let source = control.check().unwrap_err();
        let (status, retry) = (source.status_code(), source.retry_hint());
        let error = Error::Sql {
            source: DataFusionError::External(Box::new(source)),
        };
        assert_eq!(error.status_code(), status);
        assert_eq!(error.retry_hint(), retry);
        assert_eq!(error.output_msg(), "SQL operation failed");
    }

    #[test]
    fn native_keeps_sdk_categories() {
        use araphor_analysis_sdk::{Error as SdkError, ErrorCode};

        for (code, failure) in [
            (ErrorCode::Invalid, Failure::InvalidQuery),
            (ErrorCode::Incompatible, Failure::Unsupported),
            (ErrorCode::Unauthorized, Failure::Denied),
            (ErrorCode::Incomplete, Failure::StorageUnavailable),
            (ErrorCode::Limit, Failure::InputTooLarge),
            (ErrorCode::Failed, Failure::EvaluationFailed),
        ] {
            for wrapper in 0..4 {
                let contract = SdkError::contract(code, "private contract field");
                let (status, retry) = (contract.status_code(), contract.retry_hint());
                let source: Box<dyn std::error::Error + Send + Sync> = match wrapper {
                    0 => Box::new(contract),
                    1 => Box::new(Error::Contract { source: contract }),
                    2 => Box::new(araphor_data::Error::AnalysisContract {
                        source: contract,
                        location: snafu::location!(),
                    }),
                    _ => Box::new(araphor_package_runtime::Error::AnalysisContract {
                        source: contract,
                        location: snafu::location!(),
                    }),
                };
                let native = DataFusionError::Context(
                    "native stage".into(),
                    Box::new(DataFusionError::External(source)),
                );
                assert_eq!(Failure::native(&native), failure, "{code:?}/{wrapper}");
                let error = Error::Sql { source: native };
                assert_eq!(Failure::from(&error), failure, "{code:?}/{wrapper}");
                assert_eq!(error.status_code(), status, "{code:?}/{wrapper}");
                assert_eq!(error.retry_hint(), retry, "{code:?}/{wrapper}");
                assert_eq!(error.output_msg(), "SQL operation failed");
            }
        }
    }

    #[test]
    fn runtime_errors_keep_categories() {
        use araphor_data::PackageErrorCodeV1 as Code;
        use araphor_package_runtime::Error as RuntimeError;

        for native in [false, true] {
            for (code, failure, status) in [
                (
                    Code::Invalid,
                    Failure::InvalidQuery,
                    StatusCode::InvalidArguments,
                ),
                (
                    Code::Limit,
                    Failure::InputTooLarge,
                    StatusCode::InvalidArguments,
                ),
                (Code::Denied, Failure::Denied, StatusCode::PermissionDenied),
                (
                    Code::Unsupported,
                    Failure::Unsupported,
                    StatusCode::Unsupported,
                ),
                (
                    Code::Incomplete,
                    Failure::StorageUnavailable,
                    StatusCode::Unavailable,
                ),
            ] {
                let source = Box::new(std::io::Error::other("backend detail"));
                let runtime = if native {
                    RuntimeError::PackageNative {
                        code,
                        operation: "test native operation",
                        source,
                        location: snafu::location!(),
                    }
                } else {
                    RuntimeError::PackageWasm {
                        code,
                        operation: "test Wasm operation",
                        source,
                        location: snafu::location!(),
                    }
                };
                let error = Error::Sql {
                    source: DataFusionError::Shared(std::sync::Arc::new(DataFusionError::Context(
                        "physical package".into(),
                        Box::new(DataFusionError::External(Box::new(runtime))),
                    ))),
                };
                assert_eq!(Failure::from(&error), failure, "{code:?}/{native}");
                assert_eq!(error.status_code(), status, "{code:?}/{native}");
                assert_eq!(error.retry_hint(), RetryHint::NonRetryable);
                assert_eq!(error.output_msg(), "SQL operation failed");
            }
        }
    }

    #[test]
    fn runtime_capacity_can_retry() {
        let runtime = araphor_package_runtime::Error::AnalysisBusy {
            resource: "component evaluations",
            requested: 1,
            location: snafu::location!(),
        };
        let error = Error::Sql {
            source: DataFusionError::External(Box::new(runtime)),
        };
        assert_eq!(Failure::from(&error), Failure::Busy);
        assert_eq!(error.status_code(), StatusCode::Unavailable);
        assert_eq!(error.retry_hint(), RetryHint::Retryable);

        let runtime = araphor_package_runtime::Error::from(
            araphor_data::PackageErrorCodeV1::Denied.error("runtime grant"),
        );
        let error = Error::Sql {
            source: DataFusionError::External(Box::new(runtime)),
        };
        assert_eq!(Failure::from(&error), Failure::Denied);
        assert_eq!(error.status_code(), StatusCode::PermissionDenied);
    }
}
