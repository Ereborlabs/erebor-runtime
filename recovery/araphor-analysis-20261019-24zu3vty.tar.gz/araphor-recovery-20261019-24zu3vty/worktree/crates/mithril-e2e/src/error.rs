use std::any::Any;
use std::path::PathBuf;
use std::time::Duration;

use erebor_runtime_error::{ErrorExt, RetryHint, StatusCode};
use snafu::{Location, Snafu};

#[derive(Debug, Snafu)]
#[snafu(visibility(pub(crate)))]
pub enum Error {
    #[snafu(display("Mithril test input `{path:?}` is invalid: {reason}"))]
    InvalidInput {
        path: PathBuf,
        reason: String,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Mithril test I/O failed for `{path:?}`: {source}"))]
    Io {
        path: PathBuf,
        source: std::io::Error,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display(
        "Mithril test timed out after {limit:?} while waiting for {operation} at `{path:?}`: {diagnostic}"
    ))]
    Timeout {
        path: PathBuf,
        operation: String,
        limit: Duration,
        diagnostic: String,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Mithril test JSON failed for `{path:?}`: {source}"))]
    Json {
        path: PathBuf,
        source: serde_json::Error,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Mithril test command `{program}` failed: {reason}"))]
    Command {
        program: String,
        reason: String,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Mithril Interceptor test failed: {source}"))]
    Interceptor {
        source: erebor_interceptor::Error,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Araphor data test failed: {source}"))]
    Data {
        #[snafu(source(from(araphor_data::Error, Box::new)))]
        source: Box<araphor_data::Error>,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Araphor query test failed: {source}"))]
    Query {
        #[snafu(source(from(araphor_query::Error, Box::new)))]
        source: Box<araphor_query::Error>,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Mithril node identity test failed: {source}"))]
    Node {
        #[snafu(source(from(mithril_node::Error, Box::new)))]
        source: Box<mithril_node::Error>,
        #[snafu(implicit)]
        location: Location,
    },
    #[snafu(display("Mithril policy test failed: {source}"))]
    Policy {
        source: mithril_control::Error,
        #[snafu(implicit)]
        location: Location,
    },
}

pub type Result<T> = std::result::Result<T, Error>;

impl ErrorExt for Error {
    fn status_code(&self) -> StatusCode {
        match self {
            Self::InvalidInput { .. } | Self::Json { .. } => StatusCode::InvalidArguments,
            Self::Io { .. } | Self::Command { .. } => StatusCode::External,
            Self::Timeout { .. } => StatusCode::DeadlineExceeded,
            Self::Interceptor { source, .. } => source.status_code(),
            Self::Data { source, .. } => source.status_code(),
            Self::Query { source, .. } => source.status_code(),
            Self::Node { source, .. } => source.status_code(),
            Self::Policy { source, .. } => source.status_code(),
        }
    }

    fn retry_hint(&self) -> RetryHint {
        match self {
            Self::Io { source, .. } => RetryHint::from_io_error(source),
            Self::InvalidInput { .. }
            | Self::Json { .. }
            | Self::Command { .. }
            | Self::Timeout { .. } => RetryHint::NonRetryable,
            Self::Interceptor { source, .. } => source.retry_hint(),
            Self::Data { source, .. } => source.retry_hint(),
            Self::Query { source, .. } => source.retry_hint(),
            Self::Node { source, .. } => source.retry_hint(),
            Self::Policy { source, .. } => source.retry_hint(),
        }
    }

    fn as_any(&self) -> &dyn Any {
        self
    }
}
