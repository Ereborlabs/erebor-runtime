# Phase 7.1: Contracts And DuckDB Proof

Current command status, 2026-10-19: The old Analysis owner and its qualification
harness have been removed. The cases `offline-exact`
are no longer accepted by `mithril_discovery_test`. The commands and results
below remain historical proof for their recorded source. They do not qualify
the current replacement. Read the [current plan](../../araphor-package-jobs.md)
for the supported path and remaining work.

Freeze the data and investigation contracts before live storage changes.

## Intended end state

A recorded manifest produces deterministic atoms and an exact native preview.
The selected DuckDB binding passes offline durability, cancellation and
isolated-query checks. SQL bounds match full authorized-input results in the
recorded proof. The corpus and expected outcomes are executable.
Entry: Mithril 6.2 and 6.3 contracts. Status: **Done** for this offline design.

This offline result does not qualify the selected segment-backed raw owner.
7.2 reuses these public contracts and query-isolation checks, then replaces
raw persistence and reruns recovery proof. DuckDB remains the metadata and
derived-state engine; no new backend abstraction is required.

## Implementation flow

```text
Engineer submits a bounded recorded manifest
  -> DiscoveryInputManifestV1 validates identity, bytes, context and coverage
  -> DiscoveryOwner::derive_recorded produces exact atoms and unresolved counts
  -> existing compiler/simulator checks the fixture-supplied candidate
  -> mithril-e2e compares canonical output with the frozen oracle

Engineer runs storage proof
  -> public AnalysisStore methods commit validated evidence and receipt progress
  -> process stops before or after commit
  -> reopen returns the complete old or new state
  -> isolated query worker receives only authorized bounded inputs
  -> forbidden SQL or worker failure returns a typed failure
```

## Changes in implementation order

1. Reuse Control `src/discovery/model.rs`, `recorded.rs`, `context.rs`,
   `investigation.rs` and current exact derivation. Freeze the records in
   engine-design.md: source key, kernel sequence, coverage revision, context,
   profiles, receipts, assessments, suggestions and publication references.
   Canonical digests exclude database positions, run IDs and model output.
2. Add `crates/araphor-data` as a library with the first concrete
   `AnalysisStore` module under `src/analysis/`. It must not depend on
   `mithril-control`. Control keeps source authentication and passes the exact
   validated source identity, framed records, and coverage to the data owner.
   The data owner computes the durable source key. Pin one DuckDB Rust binding/build
   in Cargo and record its version in the fixture manifest. Use one writer,
   explicit transactions and local filesystem checks. No storage trait or
   production SQLite/DuckDB switch is required.
3. Specify how existing `EvidenceIntakeOwner::receive_group` and
   `receive_coverage` use the data owner's durability contract. Preserve authenticated
   identity, contiguous ACK, gap and retransmission rules. No generic public
   Ingest RPC or producer SDK is added. The input is the existing Node
   contract; only its durable destination changes in 7.2.
   After Control authenticates and validates a group, pass the exact
   `EvidenceIntakeIdentityV1` and `ValidatedEvidenceBatchV1` with CPU, cursor
   range, shared framed bytes, and frame ends to AnalysisStore. The store
   computes the source key. In 7.2 it syncs self-contained raw segment commits
   before publishing the durable receipt. Catalogue publication does not
   delay raw ACK; DuckDB holds no batch-offset directory.
   `Accepted` means the submitted end cursor is contiguous and durable;
   `Pending` means a gap remains. Control issues only the durable contiguous
   ACK. For coverage, pass the validated encoded report, CPU and revision as
   `ValidatedCoverageV1`; commit it with the coverage receipt before ACK.
4. Freeze `StorePosition(commit_revision, ordinal)`, store UUID/recovery epoch,
   relation revisions, processor progress and retained floors. Keep source
   cursors distinct. Freeze query `append`, `replace`, checkpoint, health,
   terminal and error frame schemas. A trace terminal result remains separate
   from gRPC stream closure.
5. Qualify sqlparser-rs with DuckDbDialect and offline syntax/relation checks. Pin the
   parser/engine pair; parsing alone is not semantic validation. Compare
   optimized extraction with full authorized-input evaluation in DuckDB.
   Test aliases, timestamp parameters, AND/OR, CTE reuse, joins, nested
   predicates, nulls and exact window endpoints. Prove untrusted SQL runs only
   in a no-network, no-credential, OS-limited worker with in-memory DuckDB.
   Use the isolation contract in engine-design.md, not a SELECT-prefix check.
   Phase 7.3 implements trusted extraction and internal evaluation.
   Observability 3 implements production client SQL admission and worker
   isolation. This offline proof does not qualify public SQL access.
6. Extend `crates/mithril-e2e/fixtures/discovery/manifest.json` and `pilot.json`.
   Pin source, context, policy, coverage, expected rows and proof kind.
   Include repeats, rare valid work, poisoned baseline, deployment drift,
   credential denial, missing provider evidence and malicious context text.
   Freeze workload/time train/validation/holdout splits before AI experiments.
7. Keep existing `offline-exact` and add `storage-contract` to
   `src/bin/mithril_discovery_test.rs`. Implement cases in the existing
   `src/discovery/` family. Call public AnalysisStore methods with validated
   fixture inputs; do not build private database transactions in the e2e
   harness. This case does not call the live Node intake path.

## Unit tests and end-to-end proof

Unit tests beside the owners must check schema N/N+1 bounds, duplicate and
conflicting identity, count conservation, absent bindings, canonical ordering,
unknown runtime conditions, source continuity, transaction rollback and
forbidden SQL. Test a crash after commit but before the caller observes success
in a separate process. The production ACK test belongs to 7.2.

The `storage-contract` e2e case must commit through public AnalysisStore
methods, reopen the store, and read the same identity, receipt, coverage and
counts. Control policy state remains unchanged. The separate offline worker
test proves process isolation and failure without opening the data store.
Record the store identity, revisions, source receipt, counts and result digests.
The production intake-path proof, ACK and batch latency, disk reuse and
checkpoint measurements belong to 7.2.
Trusted read plans and bounded extraction belong to 7.3. Production worker
limits belong to Observability 3. New performance measurements require user
approval. No benchmark result follows from choosing DuckDB.

Commands after the new case is implemented:

```sh
cargo test -p araphor-data
cargo test -p mithril-control
cargo run -p mithril-e2e --bin mithril_discovery_test -- --case offline-exact --output-directory /tmp/araphor-offline
cargo run -p mithril-e2e --bin mithril_discovery_test -- --case storage-contract --output-directory /tmp/araphor-storage-contract
bash .github/scripts/verify-rust-ci.sh
```

## Completion gate

Pass DE-IDENTITY, DE-AGGREGATE, DE-REPLAY and DE-PREVIEW for this recorded slice
with nonzero test counts and result digests. Prove the offline DE-STORE
transaction/reopen and DE-QUERY parser/isolation prerequisites. Full DE-STORE
needs the production intake and recovery checks in 7.2. Full DE-QUERY and
executable follow frames need QueryOwner in 7.3; wire-level gRPC frame checks
belong to Observability 3. A binding that fails durability or isolation blocks
live integration. Do not substitute another backend without approval. No
production intake cutover, public API, model runtime, or policy publication is
part of this phase.

## Implementation result

**Done for the offline scope.** The current working tree is based on
`2d8242e9`. AnalysisStore and SQL admission are in `araphor-data`. Public
store methods commit validated framed records, coverage, and source receipts.
A public read returns retained count and digest-checked coverage. The
separate-process post-commit test proves
reopen after the writer exits before its caller observes success. The tests
reject schema versions 0 and 2 for the version-1 store, conflicting retries,
and forbidden SQL. They check binding cancellation and safe SQL lower bounds
against full authorized-input results. The OS-isolated worker test passed with
`--ignored`; it is not a public query service.

The 7.1 simplification uses one admitted syntax tree for SQL bound checks.
Both data commit paths use one private method for relation and store revisions.
Tests check the affected relation revisions. No owner or persistence boundary
changed.

`offline-exact` passed at
`/tmp/araphor-simplify.bO8mk9/offline-exact/result.json`. Its recorded oracle
has three accepted records, one duplicate delivery, one unresolved record, a
nonzero snapshot digest, exact replay, and one synthetic native preview. It
made zero live lookups and no production authority claim. `storage-contract`
passed at `/tmp/araphor-simplify.bO8mk9/storage-contract/result.json` with nine
asserted contracts. It retained three events, contiguous cursor 3, coverage
revision 1, commit revision 2, and unchanged identity, receipt, report, and
count after reopen. The independent Control policy state did not change.
The pilot fixture pins DuckDB Rust binding 1.10505.0 (core 1.5.5),
sqlparser 0.63.0, distinct workload IDs,
and non-overlapping train, tune, held-out, and forbidden time windows.

`bash .github/scripts/verify-rust-ci.sh` passed formatting, workspace check,
strict lint, and workspace all-targets tests on this working-tree Rust source.
The run includes 11 passing `araphor-data` tests with two ignored and 190 passing
Control library tests with two ignored. Control still uses its existing live
evidence store. Production Node intake, durable ACK measurements, and recovery
belong to 7.2. QueryOwner and bounded extraction belong to 7.3. Production
SQL admission, bounded asynchronous execution and wire-level gRPC frames belong to
Observability 3.
