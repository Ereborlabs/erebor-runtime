#!/usr/bin/env python3
"""Check the final custody inputs. Create an archive only with --create."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


BASELINE = "6a25ba1b34dbaa0a553b1883058938683ce7aaab"
PREFIX = "crates/araphor-analysis_back/"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--evidence", type=Path, required=True)
parser.add_argument("--sources", type=Path, required=True)
parser.add_argument("--proofs", type=Path, required=True)
parser.add_argument("--create", type=Path)
args = parser.parse_args()
repo, evidence = args.repo.resolve(), args.evidence.resolve()
entries = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*arguments, data=None):
    return subprocess.run(
        ["git", "-C", str(repo), *arguments], input=data,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
    ).stdout


def add(name, kind, data):
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or str(path) != name or name in entries:
        raise ValueError(f"unsafe or duplicate archive path: {name}")
    entries[name] = (kind, data)


audit_path = evidence / "maps/final-nine361/audit.json"
source_path = args.sources.resolve()
audit = json.loads(audit_path.read_bytes())
sources = json.loads(source_path.read_bytes())
remaining = {item["path"]: item["sha256"] for item in audit["remaining_files"]}
if audit["baseline"] != BASELINE or len(remaining) != 9 or not sources:
    raise ValueError("the baseline, remaining-file count, or current source count differs")
current = {
    str(path.relative_to(repo)) for path in (repo / PREFIX).rglob("*") if path.is_file()
}
if current != remaining.keys():
    raise ValueError("the current Back tree differs from the exact nine-file cut")
tree = git("ls-tree", "-rz", BASELINE, "--", PREFIX).split(b"\0")
objects = []
for row in filter(None, tree):
    header, name = row.split(b"\t", 1)
    mode, kind, oid = header.split()
    if kind != b"blob" or mode not in (b"100644", b"100755"):
        raise ValueError("the baseline contains a non-file entry")
    objects.append((name.decode(), oid))
if len(objects) != 208 or len({path for path, _ in objects}) != 208:
    raise ValueError("the baseline does not contain exactly 208 unique original files")
blobs = io.BytesIO(git("cat-file", "--batch", data=b"\n".join(oid for _, oid in objects) + b"\n"))
for name, oid in objects:
    found, kind, size = blobs.readline().split()
    data = blobs.read(int(size))
    if found != oid or kind != b"blob" or blobs.read(1) != b"\n":
        raise ValueError(f"invalid Git blob response: {name}")
    if name in remaining:
        path = repo / name
        if path.is_symlink() or digest(data) != remaining[name] or path.read_bytes() != data:
            raise ValueError(f"the remaining original differs: {name}")
    add("old/" + name, "remaining" if name in remaining else "old", data)
for name, expected in sources.items():
    path = repo / name
    data = path.read_bytes()
    if path.is_symlink() or digest(data) != expected:
        raise ValueError(f"the current source differs: {name}")
    add("current/" + name, "current", data)
proof_paths = set()
source_entry = None
for line in args.proofs.read_text().splitlines():
    if not line or line.startswith("#"):
        continue
    expected, name = line.split("  ", 1)
    path = Path(name)
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise ValueError(f"the proof is not an absolute regular file: {name}")
    path = path.resolve()
    data = path.read_bytes()
    if path in proof_paths or digest(data) != expected:
        raise ValueError(f"the proof is duplicated or changed: {name}")
    proof_paths.add(path)
    if path.is_relative_to(evidence):
        archive_path = "proof/tmp/" + str(path.relative_to(evidence))
    elif path.is_relative_to(repo):
        archive_path = "proof/repo/" + str(path.relative_to(repo))
    else:
        raise ValueError(f"the proof is outside the selected roots: {name}")
    add(archive_path, "proof", data)
    if path == source_path:
        source_entry = archive_path
if not {audit_path, source_path}.issubset(proof_paths):
    raise ValueError("the proof list must include the nine-file audit and current source map")
for name in ("create.py", "verify.py"):
    add("custody/" + name, "custody", Path(__file__).with_name(name).read_bytes())
manifest = (
    f"# baseline {BASELINE}\n"
    f"# head {git('rev-parse', 'HEAD').decode().strip()}\n"
    f"# sources {source_entry}\n"
    "# kind sha256 archive-path\n"
    + "".join(f"{kind} {digest(data)} {name}\n" for name, (kind, data) in sorted(entries.items()))
).encode()
summary = {
    "baseline": BASELINE, "original_files": 208, "remaining_files": 9,
    "current_files": len(sources), "proof_files": len(proof_paths),
    "payload_bytes": sum(len(data) for _, data in entries.values()) + len(manifest),
    "manifest_sha256": digest(manifest), "archive_created": False,
}
if args.create is not None:
    with args.create.open("xb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed:
            with tarfile.open(mode="w", fileobj=compressed) as archive:
                payloads = {name: data for name, (_, data) in entries.items()}
                payloads["MANIFEST.txt"] = manifest
                for name, data in sorted(payloads.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
    summary.update(
        archive_created=True, archive=str(args.create), archive_bytes=args.create.stat().st_size,
        archive_sha256=digest(args.create.read_bytes()),
    )
print(json.dumps(summary, indent=2))
