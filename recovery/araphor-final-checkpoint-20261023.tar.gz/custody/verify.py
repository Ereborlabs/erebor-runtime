#!/usr/bin/env python3
"""Read an archive without extracting it. Compare its digest with the custody record."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("archive", type=Path)
parser.add_argument("--sha256", required=True)
parser.add_argument("--repo", type=Path)
args = parser.parse_args()
checksum = hashlib.sha256()
with args.archive.open("rb") as source:
    for block in iter(lambda: source.read(1024 * 1024), b""):
        checksum.update(block)
if checksum.hexdigest() != args.sha256:
    raise ValueError("the archive digest differs from the external custody record")
with tarfile.open(args.archive, "r:gz") as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    if len(names) != len(set(names)):
        raise ValueError("the archive contains duplicate paths")
    for member in members:
        path = PurePosixPath(member.name)
        if not member.isfile() or path.is_absolute() or ".." in path.parts or str(path) != member.name:
            raise ValueError(f"the archive contains an unsafe entry: {member.name}")
    manifest = archive.extractfile("MANIFEST.txt").read().decode()
    baseline = next(line.split()[2] for line in manifest.splitlines() if line.startswith("# baseline "))
    source_entry = next(line.split(" ", 2)[2] for line in manifest.splitlines() if line.startswith("# sources "))
    if baseline != "6a25ba1b34dbaa0a553b1883058938683ce7aaab":
        raise ValueError("the baseline commit differs")
    rows = {}
    for line in manifest.splitlines():
        if line.startswith("#"):
            continue
        kind, expected, name = line.split(" ", 2)
        if name in rows or kind not in {"old", "remaining", "current", "proof", "custody"}:
            raise ValueError(f"the manifest entry is duplicated or invalid: {name}")
        rows[name] = (kind, expected)
    if set(names) != rows.keys() | {"MANIFEST.txt"}:
        raise ValueError("the archive entries differ from the manifest")
    for name, (kind, expected) in rows.items():
        payload = archive.extractfile(name).read()
        if hashlib.sha256(payload).hexdigest() != expected:
            raise ValueError(f"the archived bytes differ: {name}")
        if args.repo is not None and kind in {"old", "remaining"}:
            original = subprocess.check_output([
                "git", "-C", str(args.repo), "show", baseline + ":" + name.removeprefix("old/"),
            ])
            if original != payload:
                raise ValueError(f"the original differs from Git: {name}")
    counts = {kind: sum(row[0] == kind for row in rows.values()) for kind in {"old", "remaining", "current", "proof", "custody"}}
    if counts["old"] + counts["remaining"] != 208 or counts["remaining"] != 9:
        raise ValueError("the original, remaining, or current source count differs")
    audit = json.load(archive.extractfile("proof/tmp/maps/final-nine361/audit.json"))
    remaining = {"old/" + item["path"]: item["sha256"] for item in audit["remaining_files"]}
    if remaining != {name: expected for name, (kind, expected) in rows.items() if kind == "remaining"}:
        raise ValueError("the nine original files differ from their audit")
    if rows.get(source_entry, (None,))[0] != "proof":
        raise ValueError("the selected source map is not an archived proof file")
    sources = json.load(archive.extractfile(source_entry))
    if not sources or counts["current"] != len(sources):
        raise ValueError("the current source count differs from its source map")
    if {"current/" + name: value for name, value in sources.items()} != {
        name: expected for name, (kind, expected) in rows.items() if kind == "current"
    }:
        raise ValueError("the current sources differ from their source map")
print(json.dumps({
    "archive_sha256": checksum.hexdigest(), "original_files": 208,
    "remaining_files": 9, "current_files": len(sources), "proof_files": counts["proof"],
    "all_member_hashes_match": True, "no_duplicate_paths": True,
    "originals_compared_with_git": args.repo is not None,
}, indent=2))
