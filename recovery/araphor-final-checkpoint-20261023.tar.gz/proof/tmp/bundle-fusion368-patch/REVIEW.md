# Fresh OCI layout validation

The stored native package context now makes one native OCI layout from the current stored artifact bytes. It checks the digest, validates the complete bundle, then checks the selected output. The existing parsed context owns this operation. The change removes a second layout build and a second context parse.

Public bundle validation keeps the original structure then encoding order. Public context creation still rejects a zero tenant first and validates the complete bundle before it selects an output. The `new` and `retained` constructors do not change. The stored path still reads and decodes every artifact in the current dependency closure. A saved digest is not proof of the current bytes.

`production.patch` changes three production files. `tests.patch` adds assertions to three existing tests in two files. The tests check a valid layout, a matching pin with an invalid duplicate artifact, a mismatched pin before structural checks, an OCI error before a mismatched pin, and complete validation through the public retained-context path. Existing artifact corruption, reopen, dependency, and install-only context tests remain required.

The patch has no new type, cache, skip flag, clock, or background task. The native layout is the existing SDK type. The new public method returns a layout only after all checks pass.

Status: Not done. The parent must compile and run the relevant selectors in `packet.json`. The parent has applied the production patch. This agent has not changed live source, run Cargo, or changed a Back file. The Graph test remains the only final Back behavior gate.
