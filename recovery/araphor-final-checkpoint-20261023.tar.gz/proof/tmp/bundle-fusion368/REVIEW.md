Use this fallback only if the exact retry consolidation is insufficient. No source change is proposed for immediate application.

The preferred option is one complete checked-layout operation on PackageBundleV1. It uses the existing native OCI Layout type. It does not store a layout or add a cache, owner, wrapper, flag or schema field.

Keep public validate() unchanged in behavior and order. Factor its current structural and dependency body into a private helper. Public validate() still calls that helper and then check_encoding(). The new checked_layout(expected) method first builds one fresh Layout. A wrong digest returns None. A matching digest runs the same private helper and returns the checked native Layout. This order preserves the current native-context digest error before later bundle-contract errors.

The Data private context validator can consume that complete result and check the exact selected package, export, implementation and output. Move the full bundle.validate() call to public context() immediately before the selected-output lookup, so the public context and retained constructor boundaries remain unchanged. Keep new() and retained() unchanged. Only the private stored-context path skips the second layout build after its first complete admission has succeeded.

This needs one new method on the existing PackageBundleV1 owner because Package owns admission and OCI while Data owns context storage. It returns the already public native Layout type. The private structural helper must not become an incomplete public validation API.

The SQL-body corruption and install_package-only tests remain required. Current stored artifact bytes are still hashed against the original context pin; no saved metadata is trusted as a substitute. Per-artifact OCI decode/canonical checks remain untouched.

The method is a bounded design option. It has no patch, compile result, measured speedup or passing Graph result. Do not implement it if the existing retry change closes the observed failure.
