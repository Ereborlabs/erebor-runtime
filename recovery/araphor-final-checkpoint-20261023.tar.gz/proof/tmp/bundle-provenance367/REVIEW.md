`PackageBundleRef::retained` cannot certify a reconstructed store bundle. It only borrows the bundle and supplied digest. Current native-context validation must retain a check that binds current artifact bytes to the original context digest.

The direct counterexample is `package_context_checks_artifact`. It changes a valid SQL implementation body while keeping the descriptor unchanged. Both current context read and clean reopen must reject it. OCI decoding still accepts a correctly encoded new body; descriptor equality does not bind that body. Some valid contexts also have no `package_images` row, as `package_context_retains_closure` proves.

There is repeated work in the current path. `PackageBundleRef::new` calls `bundle.digest()`. After digest comparison, `validate_context` calls `check_output`, then `bundle.validate`, then `check_encoding`. Both digest and encoding checks build the OCI layout and hash its payload layers. They do not build a tar archive. `Layout::encode` is the separate tar operation.

The immediately justified change is the other agent's exact-retry consolidation. Keep a complete provenance validation before an identical stored context is accepted. If more consolidation is required, one existing owner can retain the freshly checked layout and digest for that call. Saved metadata alone is insufficient; no cache, format change or new state is justified here.

The Appender candidate stays held. Prepared statement reuse did not make Graph recovery pass, but the current sample is OCI hashing. This audit makes no new performance claim and changes no source or tests.
