# Exact context retry validation

At the source-state-367 timeout, Thread9 hashes OCI artifact data while the
Data writer holds a managed Graph publication transaction. The call comes
from context_retry through checked read_context_from. Other Query workers
wait for that writer. This sample shows a different operation from the prior
witness INSERT preparation.

context_rows already fully validates the input packages before retry. The
retry then decodes and validates the same retained value again. The patch
shares the existing row SELECT and structural decoder with the checked reader.
An exact retry reuses the input validation in the same transaction. A different
stored value still receives full package validation before Conflict. All other
read callers retain full validation. The change adds no validation flag, cache,
public API, trust exception, or execution owner.

The two existing test extensions check a native exact-key retry and the exact
error for a corrupt stored context body. Existing read, page, reopen, artifact,
metadata, and rollback assertions remain. No tests or Cargo ran for this TMP
proposal. See record.json for exact selectors, hashes, and qualification limits.
