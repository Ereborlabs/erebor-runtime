from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

base = Path(__file__).parent
sources_path = base / 'source369-final.json'
sources = json.loads(sources_path.read_text())
digest = lambda data: hashlib.sha256(data).hexdigest()
assert all(digest(Path(path).read_bytes()) == expected for path, expected in sources.items())
proofs = []
count = 0
for name in ('compile369', 'format369', 'package-layout369', 'data-context369',
             'query-managed369', 'graph-recovery369', 'analysis-managed369', 'clippy369'):
    record_path, log_path = base / (name + '.json'), base / (name + '.log')
    record, log = json.loads(record_path.read_text()), log_path.read_bytes()
    assert record['exit_code'] == 0 and record['source_unchanged']
    assert digest(log) == record['log_sha256']
    assert all(record['sources_before'].get(path) == expected and
               record['sources_after'].get(path) == expected
               for path, expected in sources.items())
    text = log.decode(errors='replace')
    results = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored;', text, re.M)
    count += sum(map(int, results))
    proof = {key: record.get(key) for key in ('command', 'head', 'exit_code',
             'elapsed_seconds', 'binary_sha256', 'log_sha256', 'source_unchanged')}
    proof.update(name=name, record_sha256=digest(record_path.read_bytes()),
                 passing_selectors=re.findall(r'^test ([^ ]+) \.\.\.', text, re.M),
                 tests=sum(map(int, results)))
    proofs.append(proof)
assert count == 42
audit_path = base / 'maps/final-nine361/audit.json'
audit = json.loads(audit_path.read_text())
remaining = {item['path']: item['sha256'] for item in audit['remaining_files']}
assert len(remaining) == 9
assert all(digest(Path(path).read_bytes()) == expected for path, expected in remaining.items())
feed = 'crates/araphor-analysis/src/graph/native/tests/feed.rs'
assert subprocess.check_output(['git', 'show', '744110886:' + feed]) == Path(feed).read_bytes()
result = {
    'generated_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'result': 'Done for mapped replacement qualification. Archive verification and the final nine-file deletion are not yet performed.',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'source_manifest': {'file': sources_path.name, 'sha256': digest(sources_path.read_bytes()), 'files': len(sources)},
    'sources': sources,
    'actual_proofs': proofs,
    'passing_current_tests': count,
    'remaining_originals': remaining,
    'originals_baseline': audit['baseline'],
    'inherited_method_map': {'file': 'maps/final-nine361/audit.json', 'sha256': digest(audit_path.read_bytes()), 'methods': 77, 'assertion_groups': 26},
    'earlier_maps': 'The unchanged whole-file maps and earlier qualified retirement records remain in the archive. Current checks close the remaining Discovery, Graph and native continuation gates.',
    'preserved_guards': {'graph_feed_source_unchanged_since': '744110886', 'discovery_repair_seconds': 90, 'thread_stack': 'RUST_MIN_STACK was explicitly unset in each native test invocation.'},
    'scope': 'Only affected tests and library compilation ran. No full-workspace result or benchmark is claimed.',
    'not_done_outside_reference_retirement': ['Complete migration', 'DataReadMonitor repeated interrupts', '6,000-line net production reduction'],
}
path = base / 'final-qualification369.json'
with path.open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'file': str(path), 'sha256': digest(path.read_bytes()), 'tests': count, 'source_files': len(sources), 'remaining_originals': 9}))
