set pagination off
set confirm off
set print thread-events off
set print frame-arguments none
set print elements 24
set disable-randomization off
set debuginfod enabled off
set breakpoint pending off
set non-stop off
handle SIGSEGV stop print nopass
handle SIGABRT stop print nopass
show environment RUST_MIN_STACK
python
import datetime
import time
import gdb

armed_at = None

def stamp(label):
    utc = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="milliseconds")
    elapsed = "unarmed" if armed_at is None else "%.6fs" % (time.monotonic() - armed_at)
    gdb.write("\nGRAPH_TIMEOUT utc=%s elapsed=%s event=%s\n" % (utc, elapsed, label))

class Failure(gdb.Breakpoint):
    def __init__(self, location):
        super().__init__(location, temporary=True)
        self.enabled = False
        self.silent = True
    def stop(self):
        stamp("cursor258_error_stop")
        return True

failure = Failure("/home/navid/go/src/github.com/Ereborlabs/erebor-runtime/crates/araphor-analysis/src/graph/native/tests/feed.rs:1191")

class Arm(gdb.Breakpoint):
    def __init__(self, location):
        super().__init__(location, temporary=True)
        self.silent = True
    def stop(self):
        global armed_at
        armed_at = time.monotonic()
        stamp("cursor258_repair_before_clear_and_signal")
        failure.enabled = True
        return False

Arm("/home/navid/go/src/github.com/Ereborlabs/erebor-runtime/crates/araphor-analysis/src/graph/native/tests/feed.rs:1156")
end
run
python
if gdb.selected_inferior().pid:
    stamp("run_returned_inferior_stopped")
    gdb.execute("info threads")
    gdb.execute("thread apply all bt")
else:
    stamp("inferior_exited_without_error_stop")
end
